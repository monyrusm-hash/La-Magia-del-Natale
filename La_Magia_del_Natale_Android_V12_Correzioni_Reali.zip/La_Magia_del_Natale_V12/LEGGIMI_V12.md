# Io Amo la Magia del Natale — V12 (correzione dati)

Questa versione parte **dal progetto Android V11**. La grafica natalizia azzurra e il Calendario dell'Avvento restano invariati.

## Correzioni implementate

1. **Immagini film e libri:** la ricerca delle copertine è eseguita dal codice Java Android; dopo la verifica del titolo/anno o titolo/autore e del contenuto dell'immagine, il file viene salvato nella cache privata dell'app. Una URL HTTPS locale (`https://natale.assets.local/media/...`) è servita direttamente dal `WebViewClient.shouldInterceptRequest`: la WebView non deve quindi dipendere dai permessi di caricamento immagini dei server esterni per mostrare l'immagine già scaricata. La ricerca avviene prioritariamente per gli elementi presenti nello schermo, non per tutto il catalogo in blocco. I risultati negativi sono ritentati dopo 90 secondi.
2. **Guida TV:** il recupero parte dal feed XMLTV nazionale e mostra i primi risultati verificati senza aspettare che tutte le altre fonti siano completate; tenta poi TvIt e 8 canali XMLTV aggiuntivi. Le date con palinsesti sono misurate leggendo gli eventi realmente presenti, non promesse a priori. La guida mostra lo stato dei passaggi di scaricamento e consente di scegliere tra "Film natalizi" e "Tutti i film trovati" (quando la categoria EPG identifica un film anche se il titolo non contiene Natale).
3. **Home:** mostra un film e un libro consigliati ogni giorno, le schede del catalogo e una sezione "Domani in TV" che, quando sono arrivati i dati, indica titoli, canali e orari senza inventarli. Sono mantenuti i pulsanti per Film, Guida TV, Libri e Avvento.
4. **Cache dati:** nuove chiavi V12 per ignorare eventuali risposte vuote delle versioni precedenti; preferiti e film visti rimangono nel vecchio archivio locale, per preservarli quando la firma dell'APK è la stessa.

## Limiti da verificare *prima* di dichiarare la versione funzionante

- Nessuna fonte EPG gratuita garantisce 14 giorni con film natalizi: la disponibilità effettiva è quella pubblicata dal provider. Il recupero reale deve essere verificato sulla rete del telefono.
- Nessun catalogo garantisce l'immagine di ogni film o libro. La V12 non inventa poster e non include immagini coperte da diritti nel pacchetto. I server di terzi potrebbero applicare restrizioni all'accesso. Per un'app commerciale a copertura elevata servirà un fornitore/contratto idoneo (ad esempio TMDB con licenza applicabile all'uso previsto).
- Non esistono nuove credenziali pubblicitarie AdMob; l'attivazione di ads e trattamento consensi deve essere configurata separatamente.
- **La compilazione APK non è stata eseguita in questa sessione:** non era disponibile Android SDK. Il file ZIP è un progetto sorgente da compilare e provare con Android Studio o Codex.

## Verifiche svolte

- `node --check` eseguito su `app/src/main/assets/app.js`.
- Test JS con DOM simulato: Home renderizzata, elenco TV del giorno dopo visualizzato con dati **di prova**, chiamata al bridge `loadGuide` effettuata, nuovo selettore TV presente.
- `javac` senza Android SDK: parsing del sorgente senza segnalazioni di errori sintattici; non è una compilazione Android.
- Risposta reale di feed TV, recupero di poster e installazione Samsung **non verificati** in questa sessione.

## Prompt breve per Codex

"Apri il repository monyrusm-hash/La-Magia-del-Natale e scarica `La_Magia_del_Natale_Android_V12_Correzioni_Reali.zip`. Estrai lo ZIP e compila con Gradle un APK debug v12; correggi **solo eventuali errori di compilazione**. Non fare git push, non configurare Actions, non cambiare colori o grafica. Inviami l'APK debug e il log sintetico con esito della build. Se l'APK non può essere generato, indica l'errore preciso invece di restare in esecuzione senza fine." 

Dopo l'installazione testare nell'ordine: Home, Film > locandine, Libri > copertine, Guida TV > Oggi/Domani/Tutti i film trovati e controllare lo stato delle fonti in app.
