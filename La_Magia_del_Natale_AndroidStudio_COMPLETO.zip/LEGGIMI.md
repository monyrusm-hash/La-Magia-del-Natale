# Io Amo la Magia del Natale — Film, Guida TV e Libri

## Cosa contiene questa consegna

Questa è la versione **5.0 (sorgenti e anteprima funzionante)** della web app e del progetto Android. **Non contiene un APK compilato**: nell'ambiente in cui è stata creata non sono disponibili Android SDK, Gradle né una configurazione di firma Android. La build Android dovrà essere eseguita in Android Studio o con la workflow GitHub Actions inclusa.

- `app-web/`: versione web mobile, installabile come PWA se pubblicata in HTTPS (HTML, CSS, JavaScript, cache offline e immagini originali).
- `android/`: progetto Android Java/Gradle con Activity WebView locale, integrazione nativa per recuperare la guida TV e promemoria Android.
- File separato `La_Magia_del_Natale_Anteprima_Interattiva.html`: anteprima interattiva autonoma che funziona senza installazione. Per questa modalità il caricamento automatico della guida TV può essere bloccato dal browser: è previsto il collegamento esterno.
- Immagini originali create per questo progetto, non copiate dalle app mostrate come riferimenti.

## Funzionalità implementate

1. Home illustrata con accessi rapidi a Film, TV e Libri.
2. Catalogo di 26 film: ricerca, filtri per genere, scheda con trama, streaming indicativo, link alla piattaforma / JustWatch e ricerca trailer, aggiunta ai preferiti e lista film visti.
3. Guida TV: filtri Oggi/Domani/7 giorni, canale, numero del digitale terrestre quando presente, orari in timezone `Europe/Rome`, link alla guida del canale, aggiornamento e cache. In Android i dati della guida arrivano tramite ponte Java, evitando il blocco CORS del browser. Se la fonte non dà dati, l'app non inventa programmi.
4. Promemoria TV: in Android viene impostato un allarme di sistema circa 10 minuti prima (soggetto a permessi e ottimizzazioni della batteria); in versione web il promemoria locale propone anche il calendario.
5. Libri e eBook: catalogo di 16 titoli reali, ricerca per titolo/autore, filtri, preferiti e pulsanti verso ricerche di Amazon.it per cartaceo e Kindle.
6. Sezione “Film gratis” con servizi legali (RaiPlay, Pluto TV, Mediaset Infinity, Plex, Rakuten TV e JustWatch): le disponibilità gratuite non sono garantite.
7. Preferiti, film visti e promemoria persistenti sul singolo dispositivo, senza account e senza trasferimento dati a un server proprio.
8. Layout responsivo e grafica originale con verde bosco, rosso, avorio e dettagli oro.

## Fonti esterne

Guida TV:
- `https://tvit.leicaflorianrobert.dev/epg/list.json` (programma per canale, date UTC)
- `https://tvit.leicaflorianrobert.dev/iptv/list.json` (nomi, DTT e link alle guide)
- Come fonte di consultazione manuale: `https://www.superguidatv.it/programmazione-tv/`

Queste fonti sono di terzi e **non forniscono garanzie di continuità**. Inoltre l'uso pubblico/commerciale del palinsesto può richiedere autorizzazioni o accordi con il titolare dei dati. Non sono incluse trasmissioni video, stream né altri contenuti protetti. Le immagini dei film e dei libri nell'app sono decorazioni originali, NON locandine o copertine ufficiali.

Piattaforme di streaming: liste editoriali indicative. Le catalogazioni cambiano e i collegamenti rinviano alle piattaforme ufficiali e a JustWatch per controllo manuale. Non è integrata una API di disponibilità streaming in tempo reale.

## Amazon Affiliati — ATTENZIONE PRIMA DI PUBBLICARE

Codice di affiliazione inserito nel progetto: `monyka87-21`.

La **web app** costruisce le URL di ricerca `www.amazon.it/s` con il parametro `tag=monyka87-21`. Per la **versione Android**, in osservanza della policy Amazon sulle app mobili, il parametro affiliato è **disattivato per impostazione predefinita** fino a quando l'app non sarà approvata formalmente da Amazon. Le richieste di libri aprono comunque Amazon.it nel browser esterno (mai in una WebView).

Solo dopo l'approvazione del programma Amazon per questa SPECIFICA applicazione mobile, impostare `isAffiliateApproved()` su `true` nel file `MainActivity.java`, ricompilare e pubblicare seguendo i termini attuali. Non distribuire una versione con link speciali senza approvazione. La policy Amazon richiede tra l'altro una app pubblicata su store supportato, gratuita, con contenuti originali, e vieta di visualizzare Amazon all'interno di WebView. Fonti:
- https://programma-affiliazione.amazon.it/help/operating/policies
- https://programma-affiliazione.amazon.it/help/node/topic/GQZMCDD9PB7CXV7N
- https://programma-affiliazione.amazon.it/help/node/topic/GW7ZSEASVXHFPZCY

Il testo di disclosure è presente nella sezione Libri. L'accredito effettivo delle commissioni dipende dalle condizioni e dalle approvazioni Amazon.

## Come compilare un APK Android

Prerequisiti: PC con Android Studio aggiornato, JDK 17, Android SDK Platform 35 e connessione Internet durante il primo build.

1. Estrai la cartella `android/` o lo ZIP separato `La_Magia_del_Natale_AndroidStudio_COMPLETO.zip`.
2. In Android Studio: **Open**, seleziona la cartella che contiene `settings.gradle` e `app/build.gradle`.
3. Se richiesto configura Gradle 8.10.2 e il plugin Android 8.7.3, scarica SDK 35, sincronizza il progetto.
4. Scegli **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Se la build riesce, il file sarà in `app/build/outputs/apk/debug/app-debug.apk`.
6. Installa il debug APK sul tuo dispositivo autorizzando, quando richiesto, l'installazione da questa origine.

Alternativa tramite GitHub Actions: crea un repository contenente **il contenuto** della cartella `android/` alla radice, avvia la workflow **Compila APK Android** presente in `.github/workflows/build-apk.yml` e scarica l'artefatto `Natale-Magico-debug-APK` dalla pagina dell'esecuzione, dopo che sarà terminata. Questa workflow è inclusa ma **non è stata eseguita qui**.

L'APK debug è per test: per pubblicare su Google Play occorre una build release firmata, una verifica su dispositivi reali, dichiarazioni privacy, autorizzazioni per dati TV, conformità a policy Amazon e Play Store.

## Test effettuati

Test automatizzati dell'interfaccia in Chromium con asset caricati localmente:
- home e navigazione su cinque sezioni: OK;
- 26 film, ricerca per titolo, filtri e scheda: OK;
- aggiunta preferiti e persistenza locale: OK;
- 16 libri, generazione URL Amazon cartaceo/Kindle con tag nella versione web: OK;
- guida TV con dati di test (canale, numero e orario): OK;
- promemoria in modalità web e relativa persistenza: OK;
- errori JavaScript durante i test: 0.

**Non effettuati:** compilazione APK, test effettivo su smartphone Android, test del download di palinsesti dalla rete Android e approvazione Amazon. Il comportamento dell'EPG richiede verifica su dispositivo e fonte attiva.

## Privacy e dati

I preferiti, i film visti, gli avvisi TV e una copia temporanea della guida sono salvati con `localStorage` sul dispositivo. La versione Android non prevede login o sincronizzazione cloud. Le richieste dirette al fornitore della guida e le aperture di Netflix/Disney+/Amazon o altri servizi sono soggette alle loro informative privacy. Nessun SDK pubblicitario e nessun analizzatore terzo sono stati integrati.
