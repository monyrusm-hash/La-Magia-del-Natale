package it.ioamolamagiadelnatale;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String EPG = "https://tvit.leicaflorianrobert.dev/epg/list.json";
    private static final String CHANNELS = "https://tvit.leicaflorianrobert.dev/iptv/list.json";
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff0d2e22);
        getWindow().setNavigationBarColor(0xff0d2e22);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);  // only bundled android_asset URLs
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(), "NataleNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openIfExternal(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openIfExternal(Uri.parse(url));
            }
        });
        ReminderReceiver.ensureChannel(this);
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean openIfExternal(Uri uri) {
        if ("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/")) return false;
        if ("https".equalsIgnoreCase(uri.getScheme())) openExternal(uri.toString());
        return true;
    }
    private void openExternal(String link) {
        if (link == null || !link.startsWith("https://")) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))); }
        catch (ActivityNotFoundException ex) { Toast.makeText(this, "Browser non disponibile", Toast.LENGTH_SHORT).show(); }
    }

    private static String readUrl(String urlStr) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(12000); conn.setReadTimeout(16000);
        conn.setRequestProperty("User-Agent", "NataleMagicoApp/5.0 (+GuidaTV)");
        conn.setRequestProperty("Accept", "application/json");
        try {
            int status = conn.getResponseCode();
            if (status != 200) throw new Exception("HTTP " + status);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer,0,n);
                    if(out.size() > 25_000_000) throw new Exception("Guida TV troppo grande");
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { conn.disconnect(); }
    }

    private static boolean looksChristmas(String title, String description, String category) {
        String t = title.toLowerCase(Locale.ITALIAN);
        String d = description.toLowerCase(Locale.ITALIAN);
        String c = category.toLowerCase(Locale.ITALIAN);
        String[] titles = {"natale","christmas","xmas","babbo","santa claus","santa clause","grinch","scrooge","polar express","schiaccianoci","miracolo sulla 34","miracolo nella 34","mamma, ho perso","mamma ho perso","mamma, ho riperso","festa in casa muppet","holiday","love actually","una poltrona per due","elf -","elf:","jingle jangle","klaus","noelle","frosty","re magi"};
        for (String term : titles) if(t.contains(term))return true;
        if (c.contains("film") || c.contains("cinema")) {
            return d.contains("natale") || d.contains("christmas") || d.contains("babbo natale") || d.contains("vigilia") || d.contains("polo nord");
        }
        return false;
    }

    private void sendToWeb(String payload) {
        if(web != null)runOnUiThread(() -> web.evaluateJavascript(
            "window.nativeGuideReady(" + JSONObject.quote(payload) + ");", null));
    }
    private void fetchGuide() {
        new Thread(() -> {
            try {
                JSONArray epg = new JSONArray(readUrl(EPG));
                JSONArray channels = new JSONArray();
                JSONArray shows = new JSONArray();
                // Use only Christmas results; avoids sending megabytes into Android WebView.
                for(int i=0;i<epg.length();i++) {
                    JSONObject channel=epg.optJSONObject(i);
                    if(channel==null)continue;
                    JSONArray programs=channel.optJSONArray("programs");
                    if(programs==null)continue;
                    for(int j=0;j<programs.length();j++) {
                        JSONObject p=programs.optJSONObject(j);
                        if(p==null)continue;
                        String title=p.optString("title","");
                        String desc=p.optString("description","");
                        String cat=p.optString("category","");
                        if(!looksChristmas(title,desc,cat))continue;
                        JSONObject out=new JSONObject();
                        out.put("title",title);out.put("desc",desc);out.put("category",cat);
                        out.put("start",p.optString("start",""));out.put("end",p.optString("end",""));
                        out.put("channelId",channel.optString("id",""));
                        shows.put(out);
                    }
                }
                try {
                    JSONArray rawChannels=new JSONArray(readUrl(CHANNELS));
                    for(int i=0;i<rawChannels.length();i++){
                        JSONObject c=rawChannels.optJSONObject(i);if(c==null)continue;
                        JSONObject out=new JSONObject();
                        out.put("id",c.optString("tvg_slug",""));
                        out.put("name",c.optString("name",""));
                        out.put("number",c.opt("dtt_num"));
                        out.put("guide",c.optString("raw_guide_link","https://www.superguidatv.it/programmazione-tv/"));
                        channels.put(out);
                    }
                }catch(Exception ignored){
                    // Schedules remain available without channel number if the second API fails.
                    for(int i=0;i<epg.length();i++){
                        JSONObject c=epg.optJSONObject(i);if(c==null)continue;
                        channels.put(new JSONObject().put("id",c.optString("id", ""))
                            .put("name",c.optString("name", "")));
                    }
                }
                sendToWeb(new JSONObject().put("shows",shows).put("channels",channels).toString());
            }catch(Exception err){
                try{sendToWeb(new JSONObject().put("error",err.toString()).toString());}
                catch(Exception ignored){}
            }
        },"GuidaTV-Downloader").start();
    }

    public class Bridge {
        @JavascriptInterface public void loadGuide(){fetchGuide();}
        @JavascriptInterface public boolean isAffiliateApproved(){ return false; /* Set true only AFTER Amazon approves this mobile app. */ }
        @JavascriptInterface public void openUrl(String url){runOnUiThread(() -> openExternal(url));}
        @JavascriptInterface public void scheduleReminder(String id, String title, long when) {
            if (when < System.currentTimeMillis()) return;
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
                }
            });
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            it.putExtra("title",title);it.putExtra("id",id);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            // No exact-alarm permission required. Android may delay this notification slightly.
            if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }
        @JavascriptInterface public void cancelReminder(String id){
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(am!=null && pi!=null){am.cancel(pi);pi.cancel();}
        }
    }
    @Override @SuppressWarnings("deprecation") public void onBackPressed() {
        web.evaluateJavascript("window.nataleBack ? window.nataleBack() : false", result -> {
            if(!"true".equals(result))runOnUiThread(this::finish);
        });
    }
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
