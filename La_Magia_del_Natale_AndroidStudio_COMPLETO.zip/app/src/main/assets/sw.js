const CACHE='natale-magico-v5';
const ESSENTIAL=['./','./index.html','./style.css','./app.js','./catalog.js','./assets/villaggio.webp','./assets/slitta.webp','./assets/pattinaggio.webp','./assets/libri.webp','./assets/mercatino.webp','./assets/baita.webp','./assets/icon-192.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ESSENTIAL)));self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==self.location.origin)return;e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(ca=>ca.put(e.request,copy));}return r;})))});
