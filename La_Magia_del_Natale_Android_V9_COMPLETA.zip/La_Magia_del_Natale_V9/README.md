# 🎄 Io Amo la Magia del Natale — Android V9

App Android per film di Natale, guida TV italiana, libri ed eBook, preferiti e **Calendario dell’Avvento**.

Il tema visuale è azzurro cielo e neve con luci oro, dettagli rossi natalizi, slitta di Babbo Natale e villaggio incantato. Illustrazione di testata originale. Le locandine film e copertine libro vengono richieste a cataloghi reali a runtime; per i titoli non riconosciuti mostra un segnaposto chiaramente etichettato.

## Preparazione APK

Questo archivio contiene i sorgenti Android e non contiene un APK precompilato. Per generare `app-debug.apk`:

- Java 17; Android SDK 35; Gradle 8.10.2
- Eseguire dalla radice del progetto: `gradle --no-daemon assembleDebug`
- Recuperare `app/build/outputs/apk/debug/app-debug.apk`

Un workflow GitHub Actions in `.github/workflows/build-apk.yml` può fare la stessa cosa dopo aver caricato i file **estratti** nel repository e dopo avergli concesso le autorizzazioni necessarie. Codex Cloud può invece estrarre lo ZIP e creare un APK scaricabile direttamente senza effettuare il push.

## Funzioni della V9

- Home originale blu neve/oro/rosso molto natalizia
- 26 film; catalogo offline, filtro e ricerca, preferiti, film visti; piattaforme di streaming indicate come orientative, con link di verifica
- 16 libri; copertine via Google Books e pulsanti Amazon cartaceo/Kindle, con eventuale codice affiliato valido per il web
- Guida TV italiana con canale, numero, data e orario, 14 pulsanti giorno, limiti di copertura chiari; promemoria notifiche su Android
- Calendario dal 1° al 24 dicembre, una casella al giorno, con 1 film e 1 libro; bonus 25 dicembre; anteprima del primo giorno disponibile prima di dicembre
- Sezione film gratis con collegamenti a servizi legali, nessuna promessa di visione gratuita di titoli specifici
- Spazio di monetizzazione disegnato, **AdMob non attivo senza ID/CMP**

Leggi `CHANGELOG_V9.md`, `LEGGIMI_V9.md`, `PUBBLICITA_E_PRIVACY.md`.

### Nota sul Calendario

Gli abbinamenti giorno/film/libro sono **nuove proposte editoriali** per la V9. Il calendario preesistente sul sito potrebbe avere altri contenuti: non sono stati importati automaticamente da quel sito.
