package it.ioamolamagiadelnatale;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MainActivity extends Activity {
    private static final String EPG = "https://tvit.leicaflorianrobert.dev/epg/list.json";
    private static final String CHANNELS = "https://tvit.leicaflorianrobert.dev/iptv/list.json";
    private WebView web;
    private final ExecutorService artworkExecutor = Executors.newFixedThreadPool(3);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff1c639b);
        getWindow().setNavigationBarColor(0xff1c639b);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setTextZoom(112); // Lettura agevolata su display piccoli.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);  // only bundled android_asset URLs
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(), "NataleNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openIfExternal(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openIfExternal(Uri.parse(url));
            }
        });
        ReminderReceiver.ensureChannel(this);
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean openIfExternal(Uri uri) {
        if ("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/")) return false;
        if ("https".equalsIgnoreCase(uri.getScheme())) openExternal(uri.toString());
        return true;
    }
    private void openExternal(String link) {
        if (link == null || !link.startsWith("https://")) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))); }
        catch (ActivityNotFoundException ex) { Toast.makeText(this, "Browser non disponibile", Toast.LENGTH_SHORT).show(); }
    }

    private static String readUrl(String urlStr) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(12000); conn.setReadTimeout(16000);
        conn.setRequestProperty("User-Agent", "NataleMagicoApp/9.0 (+GuidaTV)");
        conn.setRequestProperty("Accept", "application/json");
        try {
            int status = conn.getResponseCode();
            if (status != 200) throw new Exception("HTTP " + status);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer,0,n);
                    if(out.size() > 25_000_000) throw new Exception("Guida TV troppo grande");
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { conn.disconnect(); }
    }

    private static boolean looksChristmas(String title, String description, String category) {
        String t = title.toLowerCase(Locale.ITALIAN);
        String d = description.toLowerCase(Locale.ITALIAN);
        String c = category.toLowerCase(Locale.ITALIAN);
        String[] titles = {"natale","christmas","xmas","babbo","santa claus","santa clause","grinch","scrooge","polar express","schiaccianoci","miracolo sulla 34","miracolo nella 34","mamma, ho perso","mamma ho perso","mamma, ho riperso","festa in casa muppet","holiday","love actually","una poltrona per due","elf -","elf:","jingle jangle","klaus","noelle","frosty","re magi"};
        for (String term : titles) if(t.contains(term))return true;
        if (c.contains("film") || c.contains("cinema")) {
            return d.contains("natale") || d.contains("christmas") || d.contains("babbo natale") || d.contains("vigilia") || d.contains("polo nord");
        }
        return false;
    }

    private void sendToWeb(String payload) {
        if(web != null)runOnUiThread(() -> web.evaluateJavascript(
            "window.nativeGuideReady(" + JSONObject.quote(payload) + ");", null));
    }
    private void fetchGuide() {
        new Thread(() -> {
            try {
                JSONArray epg = new JSONArray(readUrl(EPG));
                JSONArray channels = new JSONArray();
                JSONArray shows = new JSONArray();
                // Use only Christmas results; avoids sending megabytes into Android WebView.
                for(int i=0;i<epg.length();i++) {
                    JSONObject channel=epg.optJSONObject(i);
                    if(channel==null)continue;
                    JSONArray programs=channel.optJSONArray("programs");
                    if(programs==null)continue;
                    for(int j=0;j<programs.length();j++) {
                        JSONObject p=programs.optJSONObject(j);
                        if(p==null)continue;
                        String title=p.optString("title","");
                        String desc=p.optString("description","");
                        String cat=p.optString("category","");
                        if(!looksChristmas(title,desc,cat))continue;
                        JSONObject out=new JSONObject();
                        out.put("title",title);out.put("desc",desc);out.put("category",cat);
                        out.put("start",p.optString("start",""));out.put("end",p.optString("end",""));
                        out.put("channelId",channel.optString("id",""));
                        shows.put(out);
                    }
                }
                try {
                    JSONArray rawChannels=new JSONArray(readUrl(CHANNELS));
                    for(int i=0;i<rawChannels.length();i++){
                        JSONObject c=rawChannels.optJSONObject(i);if(c==null)continue;
                        JSONObject out=new JSONObject();
                        out.put("id",c.optString("tvg_slug",""));
                        out.put("name",c.optString("name",""));
                        out.put("number",c.opt("dtt_num"));
                        out.put("guide",c.optString("raw_guide_link","https://www.superguidatv.it/programmazione-tv/"));
                        channels.put(out);
                    }
                }catch(Exception ignored){
                    // Schedules remain available without channel number if the second API fails.
                    for(int i=0;i<epg.length();i++){
                        JSONObject c=epg.optJSONObject(i);if(c==null)continue;
                        channels.put(new JSONObject().put("id",c.optString("id", ""))
                            .put("name",c.optString("name", "")));
                    }
                }
                appendSecondaryEpg(shows,channels);
                sendToWeb(new JSONObject().put("shows",shows).put("channels",channels).toString());
            }catch(Exception err){
                try{sendToWeb(new JSONObject().put("error",err.toString()).toString());}
                catch(Exception ignored){}
            }
        },"GuidaTV-Downloader").start();
    }

    // Fonte TV di integrazione: XMLTV nazionale compresso, utile quando TvIt
    // non pubblica ancora i palinsesti dei giorni successivi.
    private static String xmlText(Element root,String tag) {
        NodeList nodes=root.getElementsByTagName(tag);
        return nodes.getLength()>0 ? nodes.item(0).getTextContent().trim() : "";
    }
    private static String parseXmlTime(String raw){
        try {
            String[] parts=raw.trim().split(" +");
            if(parts.length<2)return "";
            return OffsetDateTime.parse(parts[0]+" "+parts[1],DateTimeFormatter.ofPattern("yyyyMMddHHmmss Z",Locale.US)).toInstant().toString();
        }catch(Exception ignored){return "";}
    }
    private static int terrestrialNumber(String channel) {
        String n=channel.toLowerCase(Locale.ITALIAN).trim();
        if(n.equals("rai 1") || n.equals("rai uno"))return 1;
        if(n.equals("rai 2") || n.equals("rai due"))return 2;
        if(n.equals("rai 3") || n.equals("rai tre"))return 3;
        if(n.equals("rete 4"))return 4;
        if(n.equals("canale 5"))return 5;
        if(n.equals("italia 1"))return 6;
        if(n.equals("la7"))return 7;
        if(n.equals("tv8"))return 8;
        if(n.equals("nove"))return 9;
        if(n.equals("la5"))return 30;
        if(n.equals("rai movie"))return 24;
        if(n.equals("rai premium"))return 25;
        return 0; // Non inventiamo numerazioni per i canali sconosciuti.
    }
    private void appendSecondaryEpg(JSONArray shows,JSONArray channels) {
        HttpURLConnection conn=null;
        try {
            conn=(HttpURLConnection)new URL("https://www.open-epg.com/files/italy3.xml.gz").openConnection();
            conn.setConnectTimeout(8000);conn.setReadTimeout(13000);
            if(conn.getResponseCode()!=200)return;
            DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
            factory.setXIncludeAware(false);factory.setExpandEntityReferences(false);
            org.w3c.dom.Document doc;
            try(InputStream in=new GZIPInputStream(conn.getInputStream())) {
                doc=factory.newDocumentBuilder().parse(in);
            }
            Map<String,String> byId=new HashMap<>();
            NodeList allChannels=doc.getElementsByTagName("channel");
            for(int i=0;i<allChannels.getLength();i++){
                Element c=(Element)allChannels.item(i);String id=c.getAttribute("id");
                String name=xmlText(c,"display-name");if(name.isEmpty())name=id;
                String key="extra-"+id;byId.put(id,key);
                JSONObject channel=new JSONObject().put("id",key).put("name",name)
                    .put("guide","https://www.superguidatv.it/programmazione-tv/");
                int n=terrestrialNumber(name);if(n>0)channel.put("number",n);
                channels.put(channel);
            }
            NodeList progs=doc.getElementsByTagName("programme");
            long min=System.currentTimeMillis()-3600000L;
            long max=System.currentTimeMillis()+8L*86400000L;
            for(int i=0;i<progs.getLength();i++){
                Element pr=(Element)progs.item(i);
                String title=xmlText(pr,"title"),desc=xmlText(pr,"desc"),category=xmlText(pr,"category");
                if(!looksChristmas(title,desc,category))continue;
                String start=parseXmlTime(pr.getAttribute("start"));
                String end=parseXmlTime(pr.getAttribute("stop"));
                if(start.isEmpty() || end.isEmpty())continue;
                long when;
                try{when=java.time.Instant.parse(start).toEpochMilli();}catch(Exception ignored){continue;}
                if(when<min||when>max)continue;
                JSONObject show=new JSONObject().put("title",title).put("desc",desc)
                    .put("category",category).put("start",start).put("end",end)
                    .put("channelId",byId.getOrDefault(pr.getAttribute("channel"),""));
                shows.put(show);
            }
        }catch(Exception ignored) {
            // Gli orari primari rimangono visibili se la fonte di riserva non risponde.
        } finally {if(conn!=null)conn.disconnect();}
    }

    // Copertine non inventate: solo risultati verificati per titolo/autore o film/anno.
    private static String canon(String input) {
        String s = Normalizer.normalize(input == null ? "" : input, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ITALIAN);
        return s.replaceAll("[^a-z0-9]+", " ").trim().replaceAll(" +", " ");
    }
    private static boolean titleMatch(String a,String b) {
        String x=canon(a), y=canon(b);
        if(x.isEmpty() || y.isEmpty())return false;
        return x.equals(y) || (x.length()>5 && y.startsWith(x+" ")) || (y.length()>5 && x.startsWith(y+" "));
    }
    private static String findMovieArt(String title, int year) throws Exception {
        // Tenta sia il titolo italiano sia quello originale; associa solo risultati
        // con titolo coerente e anno di uscita compatibile, mai una locandina casuale.
        String local=canon(title);
        Map<String,String> aliases=new HashMap<>();
        aliases.put("klaus i segreti del natale","Klaus");
        aliases.put("qualcuno salvi il natale","The Christmas Chronicles");
        aliases.put("qualcuno salvi il natale 2","The Christmas Chronicles 2");
        aliases.put("mamma ho perso l aereo","Home Alone");
        aliases.put("mamma ho riperso l aereo mi sono smarrito a new york","Home Alone 2 Lost in New York");
        aliases.put("il grinch","The Grinch");
        aliases.put("polar express","The Polar Express");
        aliases.put("nightmare before christmas","The Nightmare Before Christmas");
        aliases.put("santa clause","The Santa Clause");
        aliases.put("festa in casa muppet","The Muppet Christmas Carol");
        aliases.put("jingle jangle un avventura natalizia","Jingle Jangle A Christmas Journey");
        aliases.put("un bambino chiamato natale","A Boy Called Christmas");
        aliases.put("il diario segreto di noel","The Noel Diary");
        aliases.put("scrooge canto di natale","Scrooge A Christmas Carol");
        aliases.put("l amore non va in vacanza","The Holiday");
        aliases.put("la vita e meravigliosa","It's a Wonderful Life");
        aliases.put("miracolo nella 34 strada","Miracle on 34th Street");
        aliases.put("spirited magia di natale","Spirited");
        aliases.put("buon natale da candy cane lane","Candy Cane Lane");
        aliases.put("uno rosso red one","Red One");
        String alias=aliases.getOrDefault(local,"");
        List<String> searchNames=new ArrayList<>();
        searchNames.add(title);
        if(!alias.isEmpty()&&!canon(alias).equals(local))searchNames.add(alias);
        String best="";int bestScore=-1;
        for(String q:searchNames) {
            String url="https://itunes.apple.com/search?term=" + URLEncoder.encode(q,"UTF-8")
                + "&media=movie&entity=movie&country=it&limit=25";
            JSONArray results=new JSONObject(readUrl(url)).optJSONArray("results");
            if(results==null)continue;
            for(int i=0;i<results.length();i++){
                JSONObject film=results.optJSONObject(i);if(film==null)continue;
                String name=film.optString("trackName","");
                if(!titleMatch(title,name)&&!(!alias.isEmpty()&&titleMatch(alias,name)))continue;
                int itemYear=0;
                String released=film.optString("releaseDate","");
                try{itemYear=Integer.parseInt(released.substring(0,4));}catch(Exception ignored){}
                int difference=year>0&&itemYear>0 ? Math.abs(year-itemYear):0;
                if(difference>10)continue;
                String cover=film.optString("artworkUrl100", "");
                if(!cover.startsWith("https://"))continue;
                int score=100-difference;
                if(canon(title).equals(canon(name))||canon(alias).equals(canon(name)))score+=30;
                if(score>bestScore){bestScore=score;best=cover.replace("100x100bb","600x600bb");}
            }
        }
        return best;
    }
    private static String findBookArt(String title,String author) throws Exception {
        String query="intitle:"+title+" inauthor:"+author;
        String url="https://www.googleapis.com/books/v1/volumes?q=" + URLEncoder.encode(query,"UTF-8") + "&maxResults=15";
        JSONArray results=new JSONObject(readUrl(url)).optJSONArray("items");
        if(results==null)return "";
        String surname=canon(author);if(surname.contains(" ")) surname=surname.substring(surname.lastIndexOf(' ')+1);
        for(int i=0;i<results.length();i++){
            JSONObject book=results.optJSONObject(i);if(book==null)continue;
            JSONObject info=book.optJSONObject("volumeInfo");if(info==null)continue;
            if(!titleMatch(title,info.optString("title", "")))continue;
            JSONArray authors=info.optJSONArray("authors");boolean authorOk=false;
            if(authors!=null)for(int j=0;j<authors.length();j++) {
                if(canon(authors.optString(j)).contains(surname)){authorOk=true;break;}
            }
            if(!authorOk)continue;
            JSONObject covers=info.optJSONObject("imageLinks");if(covers==null)continue;
            String cover=covers.optString("medium",covers.optString("thumbnail", ""));
            if(cover.startsWith("http://"))cover="https://"+cover.substring(7);
            if(cover.startsWith("https://"))return cover;
        }
        return "";
    }
    private void fetchArtwork(String kind,String id,String title,String author,int year){
        if(!("movie".equals(kind)||"book".equals(kind)) || id.length()>50 || title.length()>140)return;
        artworkExecutor.execute(()->{
            String url="";
            try{url="movie".equals(kind)?findMovieArt(title,year):findBookArt(title,author);}catch(Exception ignored){}
            try {
                JSONObject response=new JSONObject();
                response.put("kind",kind).put("id",id).put("url",url)
                    .put("source","movie".equals(kind)?"Apple iTunes":"Google Books");
                String text=response.toString();
                if(web!=null)runOnUiThread(()->web.evaluateJavascript("window.nativeArtworkReady("+JSONObject.quote(text)+");",null));
            }catch(Exception ignored){}
        });
    }

    public class Bridge {
        @JavascriptInterface public void loadGuide(){fetchGuide();}
        @JavascriptInterface public void requestArtwork(String kind,String id,String title,String author,int year){fetchArtwork(kind,id,title,author,year);}
        @JavascriptInterface public boolean isAffiliateApproved(){ return false; /* Set true only AFTER Amazon approves this mobile app. */ }
        @JavascriptInterface public void openUrl(String url){runOnUiThread(() -> openExternal(url));}
        @JavascriptInterface public void scheduleReminder(String id, String title, long when) {
            if (when < System.currentTimeMillis()) return;
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
                }
            });
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            it.putExtra("title",title);it.putExtra("id",id);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            // No exact-alarm permission required. Android may delay this notification slightly.
            if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }
        @JavascriptInterface public void cancelReminder(String id){
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(am!=null && pi!=null){am.cancel(pi);pi.cancel();}
        }
    }
    @Override @SuppressWarnings("deprecation") public void onBackPressed() {
        web.evaluateJavascript("window.nataleBack ? window.nataleBack() : false", result -> {
            if(!"true".equals(result))runOnUiThread(this::finish);
        });
    }
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
