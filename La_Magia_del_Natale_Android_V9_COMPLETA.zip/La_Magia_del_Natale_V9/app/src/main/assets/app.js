(() => {
'use strict';
const AMAZON_TAG = 'monyka87-21';
const EPG_URL = 'https://tvit.leicaflorianrobert.dev/epg/list.json';
const CH_URL = 'https://tvit.leicaflorianrobert.dev/iptv/list.json';
const TV_GUIDE_URL = 'https://www.superguidatv.it/programmazione-tv/';
const KEY = 'magia_natale_v5'; // Conservare i preferiti delle versioni precedenti
const ART = ['villaggio','slitta','pattinaggio','libri','mercatino','baita'];
const categories = ['Tutti','Animazione','Romantico','Commedia','Classico','Per famiglie','Avventura','Musical','Fantasy'];
const bookCategories = ['Tutti','Bambini','Classici','Per famiglie','Gialli'];
const ROMA = 'Europe/Rome';
const el = id => document.getElementById(id);
const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeUrl = u => /^https:\/\//i.test(u||'') ? esc(u) : '#';
const img = art => `assets/${ART.includes(art)?art:'villaggio'}.webp`;
const photo = art => `background-image:url('${img(art)}')`;
const norm = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
// Copertine/locandine effettive: recuperate dai cataloghi Apple/iTunes e Google Books via Android.
// Nessuna copertina viene inventata o assegnata a un titolo diverso.
const MEDIA_KEY = 'magia_natalizia_copertine_v7';
let mediaCache = {};
try { mediaCache = JSON.parse(localStorage.getItem(MEDIA_KEY)) || {}; } catch {}
const mediaRequested = new Set();
const mediaKey=(kind,id)=>kind+':'+id;
const mediaUrl=(kind,id)=>{
  const c=mediaCache[mediaKey(kind,id)];
  return c && typeof c.url==='string' && /^https:\/\//.test(c.url) ? c.url : null;
};
function mediaPhoto(item,kind){const url=mediaUrl(kind,item.id);return url ? `background-image:url('${esc(url)}')` : '';}
function applyMedia(){
 document.querySelectorAll('[data-media-kind][data-media-id]').forEach(e=>{
   const url=mediaUrl(e.dataset.mediaKind,e.dataset.mediaId);
   if(url){e.style.backgroundImage=`url("${url.replace(/"/g,'%22')}")`;e.classList.add('has-real');}
   else {e.style.backgroundImage='none';e.classList.remove('has-real');}
 });
}
function artworkTitleVariants(movie){
 const synonyms={klaus:'Klaus',chronicles:'The Christmas Chronicles',chronicles2:'The Christmas Chronicles 2',homealone:'Home Alone',homealone2:'Home Alone 2 Lost in New York',grinch:'The Grinch',polar:'The Polar Express',carol:'A Christmas Carol',nightmare:'The Nightmare Before Christmas',santa:'The Santa Clause',muppets:'The Muppet Christmas Carol',noelle:'Noelle',jingle:'Jingle Jangle A Christmas Journey',boy:'A Boy Called Christmas',falling:'Falling for Christmas',diary:'The Noel Diary',scrooge:'Scrooge A Christmas Carol',love:'Love Actually',holiday:'The Holiday',wonderful:'It\'s a Wonderful Life',miracle:'Miracle on 34th Street',spirited:'Spirited',tiffany:'Something from Tiffany\'s',candy:'Candy Cane Lane',redone:'Red One',charlie:'A Charlie Brown Christmas'};
 return [movie.title,synonyms[movie.id]].filter(Boolean);
}
function canonical(s){return norm(s).replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');}
function titleSimilar(a,b){const x=canonical(a),y=canonical(b);return !!(x&&y&&(x===y||x.length>6&&y.startsWith(x+' ')||y.length>6&&x.startsWith(y+' ')));}
async function browserArtwork(kind,o){
 // Solo immagini provenienti da risultati di catalogo che combaciano con titolo, autore e/o anno.
 try {
  if(kind==='movie'){
   const variants=artworkTitleVariants(o);
   for(const title of variants){
    const url='https://itunes.apple.com/search?term='+encodeURIComponent(title)+'&country=IT&media=movie&entity=movie&limit=25';
    const res=await fetch(url,{cache:'force-cache'});if(!res.ok)continue;
    const data=await res.json();
    const matches=(data.results||[]).filter(x=>variants.some(v=>titleSimilar(v,x.trackName||'')))
      .filter(x=>{const y=parseInt((x.releaseDate||'').slice(0,4));return !o.year||!y||Math.abs(y-o.year)<=10;});
    matches.sort((a,b)=>{const ya=parseInt((a.releaseDate||'').slice(0,4))||o.year;
      const yb=parseInt((b.releaseDate||'').slice(0,4))||o.year;
      return Math.abs(ya-o.year)-Math.abs(yb-o.year);});
    if(matches[0]?.artworkUrl100){return {url:matches[0].artworkUrl100.replace(/100x100bb/,'600x600bb'),source:'Apple iTunes'};}
   }
  } else if(kind==='book'){
   const q='intitle:'+o.title+' inauthor:'+o.author;
   const res=await fetch('https://www.googleapis.com/books/v1/volumes?q='+encodeURIComponent(q)+'&maxResults=20',{cache:'force-cache'});
   if(!res.ok)return {url:'',source:'Google Books'};
   const data=await res.json();const surname=canonical(o.author).split(' ').pop();
   const match=(data.items||[]).map(x=>x.volumeInfo||{}).find(info=>
     titleSimilar(o.title,info.title||'') && (info.authors||[]).some(a=>canonical(a).includes(surname)) &&
     (info.imageLinks?.medium||info.imageLinks?.thumbnail));
   if(match){return {url:(match.imageLinks.medium||match.imageLinks.thumbnail).replace(/^http:/,'https:'),source:'Google Books'};}
  }
 }catch(err){/* Una fonte può non consentire la richiesta nel browser. Il bridge Android rimane prioritario. */}
 return {url:'',source:kind==='book'?'Google Books':'Apple iTunes'};
}
function requestMedia(){
 applyMedia();
 const refs=[...document.querySelectorAll('[data-media-kind][data-media-id]')];
 for(const e of refs){
  const kind=e.dataset.mediaKind,id=e.dataset.mediaId;
  if(!['movie','book'].includes(kind)||!id)continue;
  const o=kind==='book'?BOOKS.find(b=>b.id===id):MOVIES.find(m=>m.id===id);
  const item=o || (e.dataset.mediaTitle?{id,title:e.dataset.mediaTitle,author:'',year:Number(e.dataset.mediaYear)||0}:null);
  if(!item)continue;
  const key=mediaKey(kind,id),cached=mediaCache[key];
  if(mediaRequested.has(key)||(cached&&Date.now()-cached.when<14*864e5))continue;
  mediaRequested.add(key);
  try{
   if(window.NataleNative&&typeof NataleNative.requestArtwork==='function'){
    NataleNative.requestArtwork(kind,id,item.title,item.author||'',item.year||0);
   }else{
    browserArtwork(kind,item).then(result=>window.nativeArtworkReady(JSON.stringify({kind,id,...result})));
   }
  }catch {mediaRequested.delete(key);}
 }
}
window.nativeArtworkReady=function(payload){
 try{const d=JSON.parse(payload); if(!['movie','book'].includes(d.kind)||!d.id)return;
  const key=mediaKey(d.kind,d.id);
  mediaCache[key]={url: /^https:\/\//.test(d.url||'') ? d.url : '',when:Date.now(),source:d.source||''};
  try{localStorage.setItem(MEDIA_KEY,JSON.stringify(mediaCache));}catch{}
  applyMedia();
 }catch{}
};
const movieById = id => MOVIES.find(m => m.id === id);
const bookById = id => BOOKS.find(m => m.id === id);
const pad = n => String(n).padStart(2,'0');
function storeGet(){ try {const a=JSON.parse(localStorage.getItem(KEY));return a && typeof a==='object'?a:{};}catch{return {};} }
const saved = storeGet();
const state = { tab:'home', filmFilter:'Tutti', bookFilter:'Tutti', query:'', dateOffset:0, favMovies: Array.isArray(saved.favMovies)?saved.favMovies:[], favBooks:Array.isArray(saved.favBooks)?saved.favBooks:[], seen:Array.isArray(saved.seen)?saved.seen:[], reminders:Array.isArray(saved.reminders)?saved.reminders:[], showFree:false, tv:[], tvLoaded:false, tvLoading:false, tvErr:'', tvUpdated:0 };
try{const cache=JSON.parse(localStorage.getItem('magia_tv_cache'));if(Array.isArray(cache?.list) && (Date.now()-cache.when)<1000*60*60*18){state.tv=cache.list;state.tvLoaded=true;state.tvUpdated=cache.when;}}catch{}
function save(){ try {localStorage.setItem(KEY,JSON.stringify({favMovies:state.favMovies,favBooks:state.favBooks,seen:state.seen,reminders:state.reminders}));}catch{} }
function toast(t){const n=el('toast');n.textContent=t;n.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>n.classList.remove('show'),2800);}
function artFor(text){let n=0;for(const c of String(text)) n=(n*31+c.charCodeAt(0))|0;return ART[Math.abs(n)%ART.length];}
function dateLocal(when,opts){return new Intl.DateTimeFormat('it-IT',{timeZone:ROMA,...opts}).format(when);}
function dateKey(when){const d=when instanceof Date?when:new Date(when);return new Intl.DateTimeFormat('en-CA',{timeZone:ROMA,year:'numeric',month:'2-digit',day:'2-digit'}).format(d);}
function localDay(offset){const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()+offset);return d;}
function htime(when){return dateLocal(new Date(when),{hour:'2-digit',minute:'2-digit',hour12:false});}
function tvCheck(title,description,category){
  const t=norm(title), d=norm(description), c=norm(category);
  const terms=['natale','christmas','xmas','babbo','santa claus','santa clause','grinch','scrooge','polar express','schiaccianoci','miracolo sulla 34','miracolo nella 34','mamma ho perso','mamma, ho perso','mamma, ho riperso','festa in casa muppet','holiday','love actually','una poltrona per due','elf -','elf:','jingle jangle','klaus','noelle','il diario segreto di noel','the nightmare before christmas','bad santa','luci di natale','frosty','re magi'];
  if (terms.some(x=>t.includes(x))) return true;
  // Nessuna classificazione sulla sola parola "neve" o su generici film romantici.
  return (c.includes('film') || c.includes('cinema')) && /(?:natale|christmas|babbo natale|vigilia|polo nord|holiday season)/.test(d);
}
function loadBrowserEpg(){
 const opt={cache:'no-store'};
 Promise.all([fetch(EPG_URL,opt).then(r=>{if(!r.ok)throw Error('Guida '+r.status);return r.json()}),fetch(CH_URL,opt).then(r=>{if(!r.ok)throw Error('Canali '+r.status);return r.json()})])
 .then(([epg,chs])=>{
  const map=Object.fromEntries((Array.isArray(chs)?chs:[]).map(c=>[c.tvg_slug,c]));
  let shows=[];
  (Array.isArray(epg)?epg:[]).forEach(c=>{(c.programs||[]).forEach(p=>{if(tvCheck(p.title,p.description,p.category))shows.push({title:p.title,desc:p.description||'',category:p.category||'',start:p.start,end:p.end,channel:c.name||'',channelId:c.id||'',number:map[c.id]?.dtt_num??null,guide:map[c.id]?.raw_guide_link||TV_GUIDE_URL});});});
  finishTv(shows);
 }).catch(err=>failTv(err?.message||'Servizio non disponibile'));
}
function finishTv(shows){
 const today=new Date();const max=new Date(today);max.setDate(max.getDate()+9);
 const unique=new Map();
 for(const x of shows){const start=new Date(x.start);if(!Number.isFinite(start.valueOf())||start<new Date(Date.now()-86400000)||start>max)continue;
  const key=`${x.channelId}/${x.start}/${x.title}`;if(!unique.has(key))unique.set(key,{...x,art:artFor(x.title)});
 }
 state.tv=Array.from(unique.values()).sort((a,b)=>new Date(a.start)-new Date(b.start));state.tvLoading=false;state.tvLoaded=true;state.tvErr='';state.tvUpdated=Date.now();
 try{localStorage.setItem('magia_tv_cache',JSON.stringify({list:state.tv,when:state.tvUpdated}));}catch{}
 render();
}
function failTv(reason){state.tvLoading=false;state.tvErr='Non è stato possibile aggiornare il palinsesto. '+String(reason||'');render();}
function refreshTv(force=false){
 if(state.tvLoading || (state.tvLoaded && !force && Date.now()-state.tvUpdated<60*60*1000))return;
 state.tvLoading=true;state.tvErr='';render();
 try{if(window.NataleNative && typeof NataleNative.loadGuide==='function'){NataleNative.loadGuide();return;}}catch{}
 loadBrowserEpg();
}
window.nativeGuideReady = function(payload){try{const data=JSON.parse(payload);if(data.error)throw Error(data.error);const maps=Object.fromEntries((data.channels||[]).map(c=>[c.id,c]));let shows=(data.shows||[]).map(p=>({...p,channel:maps[p.channelId]?.name||p.channelId,number:maps[p.channelId]?.number??null,guide:maps[p.channelId]?.guide||TV_GUIDE_URL}));finishTv(shows);}catch(err){failTv(err?.message||'Risposta non valida');}};
function nav(tab){state.tab=tab;state.query='';state.showFree=false;render();window.scrollTo(0,0);if(tab==='tv')refreshTv();}
window.nataleBack=()=>{if(!el('modal').classList.contains('hidden')){closeModal();return true;}if(state.tab!=='home'){nav('home');return true;}return false;};
function filmCard(m,wide=true){const fav=state.favMovies.includes(m.id);return `<article class="movie-card" data-action="detail" data-id="${esc(m.id)}" tabindex="0" role="button" aria-label="Scheda di ${esc(m.title)}"><div class="poster" data-media-kind="movie" data-media-id="${esc(m.id)}" style="${mediaPhoto(m,'movie')}"><span class="cover-missing"><span>🎞</span><small>Locandina non disponibile</small></span></div><div class="movie-card-body"><div class="card-title-row"><h3>${esc(m.title)}</h3><button class="star-btn ${fav?'on':''}" data-action="favMovie" data-id="${esc(m.id)}" aria-label="${fav?'Togli':'Aggiungi'} dai preferiti">${fav?'♥':'♡'}</button></div><div class="movie-meta">${esc(m.year)} · ${esc(m.genre)}</div><p>${esc(m.desc)}</p><div class="provider-tags">${(m.platforms||[]).length?m.platforms.slice(0,2).map(p=>`<span class="tag">${esc(p)}</span>`).join(''):'<span class="tag check">Piattaforma da verificare</span>'}</div></div></article>`;}
function smallCard(m){const fav=state.favMovies.includes(m.id);return `<div class="feature-card" data-action="detail" data-id="${esc(m.id)}" role="button" tabindex="0"><div class="picture" data-media-kind="movie" data-media-id="${esc(m.id)}" style="${mediaPhoto(m,'movie')}"><span class="cover-missing"><span>🎞</span><small>Locandina non disponibile</small></span></div><button class="star-btn ${fav?'on':''}" data-action="favMovie" data-id="${esc(m.id)}">${fav?'♥':'♡'}</button><div class="info"><strong>${esc(m.title)}</strong><small>${esc(m.genre)} · ${esc(m.year)}</small></div></div>`;}
function sectionTitle(title,tab){return `<div class="section-title"><h2><span class="spark">✧</span>${esc(title)}</h2>${tab?`<button class="more" data-tab="${tab}">Vedi tutti ›</button>`:''}</div>`;}
function festiveShortDate(){return dateLocal(new Date(),{weekday:'long',day:'numeric',month:'long'});}
function renderHome(){
 const shows=state.tv.filter(x=>dateKey(x.start)===dateKey(new Date()));
 return `<section class="hero hero-v9">
  <div class="hero-bg"></div><div class="hero-content">
  <div class="hero-top"><span class="gold-label">✦ LA MAGIA È QUI ✦</span><h1>Io Amo la<br><em>Magia del Natale</em></h1><p>Ogni giorno un pizzico di meraviglia, tra film, libri e luci di Natale.</p></div>
  <div class="hero-bottom"><div class="hero-stats"><strong>🎄</strong><span>${esc(festiveShortDate())}</span></div><button class="hero-cta" data-tab="advent">🎁 Apri l’Avvento</button></div>
  </div></section>
  <p class="home-welcome">✧ Benvenuto nel tuo piccolo mondo incantato ✧</p>
  <div class="quick-grid quick-grid-v9">
   <button class="quick-btn" data-tab="films"><span class="big">🎬</span><span>Film di Natale</span></button>
   <button class="quick-btn" data-tab="tv"><span class="big">📺</span><span>Guida TV</span></button>
   <button class="quick-btn" data-tab="books"><span class="big">📚</span><span>Libri & eBook</span></button>
   <button class="quick-btn" data-tab="advent"><span class="big">🎁</span><span>Calendario dell’Avvento</span></button>
  </div>
  <div class="advent-teaser"><span class="teaser-decoration">🎀</span><div><span class="gold-label">LA SORPRESA DEL GIORNO</span><h2>Una casellina, due magie</h2><p>Un film e un libro scelti per accompagnarti verso Natale.</p></div><button data-tab="advent" aria-label="Apri il Calendario dell'Avvento">Scopri ✨</button></div>
  ${sectionTitle('Film sotto l’albero','films')}<div class="feature-row">${[MOVIES[0],MOVIES[3],MOVIES[6],MOVIES[13]].map(smallCard).join('')}</div>
  ${sectionTitle('Natale sul piccolo schermo','tv')}
  <div class="paper tv-home-card"><div><span class="gold-label">📺 PROGRAMMAZIONE ITALIANA</span><h3>${state.tvLoaded?shows.length+' film natalizi oggi':'Che film danno in TV?'}</h3><p>Canale, data, orario e promemoria. Seleziona anche i prossimi giorni.</p></div><button data-tab="tv" class="small-button red">Scopri gli orari ›</button></div>
  ${sectionTitle('Libri da leggere accanto all’albero','books')}<div class="feature-row">${[BOOKS[0],BOOKS[1],BOOKS[6]].map(b=>`<div class="feature-card" data-tab="books" role="button" tabindex="0"><div class="picture" data-media-kind="book" data-media-id="${esc(b.id)}" style="${mediaPhoto(b,'book')}"><span class="cover-missing"><span>📖</span><small>Copertina non disponibile</small></span></div><div class="info"><strong>${esc(b.title)}</strong><small>${esc(b.author)}</small></div></div>`).join('')}</div>
  <div class="promo-v9"><span>✦</span><div><b>Uno spazio per i partner del Natale</b><small>Area pubblicitaria predisposta · annunci non ancora attivi</small></div></div>
  <p class="disclosure">Le illustrazioni del brand sono originali e decorative. Locandine e copertine provengono da cataloghi editoriali quando la corrispondenza è affidabile. La disponibilità streaming va verificata sulla piattaforma.</p>`;
}

const calendarDoor=(d,unlocked,preview=false)=> `<button class="door ${unlocked?'door-open':'door-locked'}" data-action="adventOpen" data-value="${d[0]}" ${unlocked?'':'disabled'} aria-label="${unlocked?'Apri':'Non ancora disponibile'} giorno ${d[0]} dell’Avvento"><span class="door-num">${d[0]}</span><span class="door-symbol">${unlocked?'✦':(d[0]%3===0?'🔔':d[0]%3===1?'❄':'🎁')}</span><small>${unlocked?'Apri la magia':'Da scoprire'}</small></button>`;
function adventOpenLimit(){
 const p=new Intl.DateTimeFormat('en-GB',{timeZone:ROMA,month:'numeric',day:'numeric'}).formatToParts(new Date());
 const month=Number(p.find(x=>x.type==='month')?.value),day=Number(p.find(x=>x.type==='day')?.value);
 return month===12?Math.min(day,25):0;
}
function renderAdvent(){
 const available=adventOpenLimit(),inDecember=available>0;
 const doors=ADVENT_DAYS.map(d=>calendarDoor(d,d[0]<=available)).join('');
 const intro=inDecember?`Oggi puoi aprire fino alla casellina <strong>${Math.min(available,24)}</strong>. Le precedenti restano disponibili.`:'Le caselline si aprono dal <strong>1° dicembre</strong>, una al giorno. Intanto puoi guardare una piccola anteprima.';
 return `<section class="section advent-page">
  <div class="advent-banner"><span class="overline">✧ 24 GIORNI DI MERAVIGLIE ✧</span><h1>Il Calendario<br><em>dell’Avvento</em></h1><p>Ogni porticina nasconde un film e un libro di Natale.</p><span class="banner-holly">🎄 🎁 🔔</span></div>
  <div class="advent-intro"><b>Benvenuto nel calendario incantato!</b><p>${intro}</p>${!inDecember?'<button class="small-button red" data-action="adventPreview">✨ Guarda l’anteprima del 1° giorno</button>':''}</div>
  <div class="door-grid" aria-label="Caselline del calendario dell’Avvento">${doors}</div>
  <div class="bonus-wrap"><button class="bonus-door ${available>=25?'available':''}" data-action="adventBonus" ${available>=25?'':'disabled'}><span>🌟</span><strong>25 Dicembre</strong><small>${available>=25?'Apri la sorpresa speciale':'La sorpresa di Natale si svela il 25 dicembre'}</small></button></div>
  <p class="disclosure">Le proposte film e libro sono scelte editoriali della nuova app; non riproducono automaticamente il calendario già pubblicato sul sito. Le copertine sono richieste ai cataloghi ufficiali quando verificabili.</p>
 </section>`;
}
function openAdventDay(day,preview=false){
 const d=day===25?ADVENT_BONUS:ADVENT_DAYS.find(x=>x[0]===day);if(!d)return;
 if(!preview && day>adventOpenLimit()){toast('Questa casellina si aprirà a dicembre 🎁');return;}
 const movie=movieById(d[2]),book=bookById(d[3]);if(!movie||!book)return;
 const isExample=preview?'<div class="advent-example">✨ ANTEPRIMA DIMOSTRATIVA · LA PORTICINA NON È ANCORA APERTA</div>':'';
 const content=`<div class="advent-modal-head">${isExample}<span class="gold-label">LA MAGIA DEL ${day} DICEMBRE</span><h2 id="modalTitle">${esc(d[1])}</h2><p>${esc(d[4])}</p></div>
 <div class="advent-reveal"><span class="advent-kicker">🎬 IL FILM DEL GIORNO</span><div class="advent-media"><div class="reveal-cover" data-media-kind="movie" data-media-id="${esc(movie.id)}" style="${mediaPhoto(movie,'movie')}"><span class="cover-missing"><small>Locandina non disponibile</small></span></div><div><h3>${esc(movie.title)}</h3><p>${esc(movie.year)} · ${esc(movie.genre)}</p><p>${esc(movie.desc)}</p><button class="small-button red" data-action="detail" data-id="${esc(movie.id)}">Scopri il film ›</button></div></div></div>
 <div class="advent-reveal"><span class="advent-kicker">📚 IL LIBRO DEL GIORNO</span><div class="advent-media"><div class="reveal-cover" data-media-kind="book" data-media-id="${esc(book.id)}" style="${mediaPhoto(book,'book')}"><span class="cover-missing"><small>Copertina non disponibile</small></span></div><div><h3>${esc(book.title)}</h3><p>${esc(book.author)}</p><p>${esc(book.desc)}</p><div class="advent-buy"><a href="${safeUrl(amazon(book.title,book.author,'paper'))}" target="_blank" rel="sponsored noopener noreferrer">📖 Cartaceo ↗</a><a href="${safeUrl(amazon(book.title,book.author,'kindle'))}" target="_blank" rel="sponsored noopener noreferrer">Kindle ↗</a></div></div></div></div>
 <p class="disclosure" style="padding:0 18px 22px">Amazon: i link nella versione web possono contenere il codice affiliato; nell'APK è necessario prima ottenere l'approvazione di Amazon. Verifica il formato disponibile.</p>`;
 openModal(content);
}
function filterInput(placeholder){return `<label class="searchbox"><span>⌕</span><input id="queryInput" value="${esc(state.query)}" autocomplete="off" aria-label="Cerca" placeholder="${esc(placeholder)}"><button data-action="clearQuery" class="clear" aria-label="Cancella ricerca">${state.query?'✕':''}</button></label>`;}
function renderFilms(){let arr=MOVIES.filter(m=>(state.filmFilter==='Tutti'||m.genre===state.filmFilter||state.filmFilter==='Classico'&&m.genre==='Classico')&&norm(m.title+' '+m.desc+' '+m.genre).includes(norm(state.query)));return `<section class="section"><div class="overline">✧ LA CINETECA INCANTATA ✧</div><h1 class="page-title">Film di Natale</h1><p class="page-subtitle">I tuoi film del cuore, i classici e le novità da scoprire.</p>${filterInput('Cerca un film di Natale…')}<div class="pills">${categories.map(c=>`<button class="pill ${state.filmFilter===c?'active':''}" data-action="filmFilter" data-value="${esc(c)}">${esc(c)}</button>`).join('')}</div><div class="section-title" style="margin-top:0"><h2>${arr.length} film da scoprire</h2><button class="more" data-action="toggleFree">${state.showFree?'Nascondi':'Film gratis ›'}</button></div>${state.showFree?renderFree():''}<div class="movie-list">${arr.map(filmCard).join('')}</div>${!arr.length?empty('Non ho trovato film con questi filtri.','Prova un altro genere o titolo.'):''}<p class="disclosure">I servizi streaming indicati sono orientativi, non una verifica in tempo reale. Nelle schede trovi i collegamenti per ricontrollare la disponibilità in Italia.</p></section>`;}
function renderFree(){return `<div class="paper" style="padding:14px;margin-bottom:16px"><h2 style="font:700 28px 'Cormorant Garamond';color:#852b37;margin:0 0 7px">🎁 Dove trovare film gratis</h2><p style="font-size:12px;line-height:1.5;color:#79634f">Solo servizi legali: alcuni titoli sono gratuiti con pubblicità o registrazione. Non tutti i film di Natale sono disponibili gratuitamente.</p><div class="free-grid">${FREE_SERVICES.map(s=>`<a href="${safeUrl(s.url)}" target="_blank" rel="noopener noreferrer" class="free-service"><span class="svc-icon">${s.icon}</span><span class="svc-info"><strong>${esc(s.name)}</strong><p>${esc(s.desc)}</p></span><span class="arr">↗</span></a>`).join('')}</div></div>`;}
function empty(title,body,button=''){return `<div class="empty"><div class="empty-icon">❄️</div><h3>${esc(title)}</h3><p>${esc(body)}</p>${button}</div>`;}
function renderTv(){const today=localDay(state.dateOffset),key=dateKey(today),items=state.tv.filter(p=>dateKey(new Date(p.start))===key),now=Date.now();const publishedUntil=state.tv.length?Math.max(...state.tv.map(p=>new Date(p.start).getTime())):null;const days=Array.from({length:14},(_,i)=>{const date=localDay(i),day=dateLocal(date,{weekday:'short'});return `<button class="day-btn ${state.dateOffset===i?'active':''}" data-action="date" data-value="${i}"><strong>${i===0?'Oggi':i===1?'Domani':esc(day)}</strong><span>${dateLocal(date,{day:'numeric',month:'short'})}</span></button>`;}).join('');return `<section class="section"><div class="overline">📺 IL NATALE SUL PICCOLO SCHERMO</div><h1 class="page-title">Guida TV</h1><p class="page-subtitle">I film natalizi in onda sulle televisioni italiane, con canale e orari locali.</p><div class="dates">${days}</div><div class="tv-status">${state.tvLoading?'<strong>✧ Sto aggiornando il palinsesto…</strong>':state.tvLoaded?`<strong>✓ ${state.tvErr?'Ultimo elenco salvato':'Guida caricata'}</strong> · ultimo aggiornamento ${dateLocal(new Date(state.tvUpdated),{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}`:'<strong>Guida TV non caricata</strong> · serve Internet per ottenere i programmi.'}<div style="margin-top:6px">Fonte: TvIt/SuperGuidaTV · Orari Europe/Rome · <button data-action="refreshTv">Aggiorna la guida ↻</button></div>${state.tvErr?`<div style="color:#ffdcb5;margin-top:6px">${esc(state.tvErr)}</div>`:''}</div><div class="tv-counter">${dateLocal(today,{weekday:'long',day:'numeric',month:'long'})} · <b>${items.length} ${items.length===1?'film':'film'} trovati</b></div>${publishedUntil && new Date(today).getTime()>publishedUntil+86400000?'<p class="tv-coverage">📅 Per questa data il palinsesto potrebbe non essere ancora stato pubblicato. Puoi consultare la guida esterna.</p>':''}${items.length?`<div class="paper">${items.map((p,i)=>{const isNow=Date.now()>=new Date(p.start).getTime()&&Date.now()<new Date(p.end).getTime();return `<div class="tv-row"><div class="tv-time"><strong>${htime(p.start)}</strong><span class="channel">${esc(p.channel)}</span>${p.number?`<span class="chno">Canale ${Number(p.number)}</span>`:''}</div><div class="tv-photo" data-media-kind="movie" data-media-id="${esc('tv-'+canonical(p.title).slice(0,38))}" data-media-title="${esc(p.title)}" data-media-year="0" aria-label="Locandina del programma, se disponibile"><span class="cover-missing"><span>📺</span></span></div><div class="tv-desc"><h3>${esc(p.title)} ${isNow?'<span class="now-badge">In onda</span>':''}</h3><p>${esc(p.desc||p.category||'Film di Natale')}</p><small>Fino alle ${htime(p.end)} · ${esc(p.category||'Programma TV')}</small><div class="tv-actions"><a class="small-button" href="${safeUrl(p.guide)}" target="_blank" rel="noopener noreferrer">Guida canale ↗</a>${new Date(p.start).getTime()>now?`<button class="small-button red" data-action="remind" data-value="${i}" data-day="${state.dateOffset}">🔔 Ricordami</button>`:''}</div></div></div>`;}).join('')}</div>`:empty(state.tvLoading?'Sto cercando nel palinsesto…':'Nessun film natalizio trovato',state.tvLoading?'Caricamento dei canali in corso.':state.tvLoaded?(state.tv.length && new Date(today) > new Date(Math.max(...state.tv.map(p=>new Date(p.start).getTime()))) ? 'La fonte non ha ancora pubblicato film natalizi per questa data. Seleziona un giorno precedente o consulta la guida completa.' : 'Nella data selezionata non risultano film natalizi riconoscibili nella guida disponibile. Puoi consultare la guida completa.'):'Puoi aprire la guida esterna anche senza caricare dati nell’app.',`<a href="${safeUrl(TV_GUIDE_URL)}" target="_blank" rel="noopener noreferrer">Apri SuperGuidaTV ↗</a>`)}<p class="disclosure">Gli orari provengono da una fonte esterna e possono variare. Non mostriamo passaggi inesistenti o non verificati. Non riproduciamo i canali televisivi.</p></section>`;}
function affiliateAllowed(){
 // Un'APK non approvato da Amazon non può usare link speciali affiliati.
 try{if(window.NataleNative?.isAffiliateApproved)return NataleNative.isAffiliateApproved();}catch{}
 return !window.NataleNative;
}
function amazon(title,author,type){const q=encodeURIComponent([title,author].filter(Boolean).join(' '));const tag=affiliateAllowed()?`&tag=${AMAZON_TAG}`:'';return `https://www.amazon.it/s?k=${q}&i=${type==='kindle'?'digital-text':'stripbooks'}${tag}`;}
function bookCard(b){const fav=state.favBooks.includes(b.id);return `<article class="book-card"><div class="book-cover" data-media-kind="book" data-media-id="${esc(b.id)}" style="${mediaPhoto(b,'book')}"><span class="cover-missing"><span>📖</span><small>Copertina non disponibile</small></span></div><div class="book-info"><div class="card-title-row"><h3>${esc(b.title)}</h3><button data-action="favBook" data-id="${esc(b.id)}" class="star-btn ${fav?'on':''}" aria-label="${fav?'Togli':'Aggiungi'} dai preferiti">${fav?'♥':'♡'}</button></div><div class="author">${esc(b.author)} · ${esc(b.genre)}</div><p>${esc(b.desc)}</p><div class="book-links"><a href="${safeUrl(amazon(b.title,b.author,'paper'))}" target="_blank" rel="sponsored noopener noreferrer">📖 Cartaceo ↗</a><a href="${safeUrl(amazon(b.title,b.author,'kindle'))}" target="_blank" rel="sponsored noopener noreferrer">Kindle ↗</a></div></div></article>`;}
function renderBooks(){const books=BOOKS.filter(b=>(state.bookFilter==='Tutti'||b.genre===state.bookFilter)&&norm(b.title+' '+b.author+' '+b.genre).includes(norm(state.query)));return `<section class="section"><div class="overline">✧ STORIE CHE ACCENDONO LE FESTE ✧</div><h1 class="page-title">Libri & eBook</h1><p class="page-subtitle">Fiabe, classici, romanzi e letture da regalare. Sfoglia la nostra libreria incantata.</p>${filterInput('Cerca titolo o autore…')}<div class="pills">${bookCategories.map(c=>`<button class="pill ${state.bookFilter===c?'active':''}" data-action="bookFilter" data-value="${esc(c)}">${esc(c)}</button>`).join('')}</div><div class="books-list">${books.map(bookCard).join('')}</div>${!books.length?empty('Nessun libro trovato','Prova con un titolo o un autore diverso.'):''}<p class="disclosure">* In qualità di Affiliato Amazon io ricevo un guadagno dagli acquisti idonei. I pulsanti aprono ricerche su Amazon.it. Il codice <b>${AMAZON_TAG}</b> è attivo nella versione web; nell’app Android si abilita solo dopo l’approvazione di Amazon. Non garantiscono la disponibilità dell'edizione cartacea o Kindle. Le copertine reali vengono cercate su Google Books e mostrate solo se associate al libro e autore corretti; altrimenti compare un segnaposto neutro.</p></section>`;}
function renderProfile(){const favM=MOVIES.filter(m=>state.favMovies.includes(m.id)),favB=BOOKS.filter(b=>state.favBooks.includes(b.id)),future=state.reminders.filter(r=>r.when>Date.now()-3600000);return `<section class="section"><div class="overline">♡ LE TUE SCELTE DI NATALE ♡</div><h1 class="page-title">I tuoi preferiti</h1><p class="page-subtitle">I preferiti, i film già visti e i promemoria salvati su questo dispositivo.</p><div class="profile-stat"><div class="stat-box"><b>${favM.length}</b><small>Film preferiti</small></div><div class="stat-box"><b>${favB.length}</b><small>Libri salvati</small></div><div class="stat-box"><b>${state.seen.length}</b><small>Film visti</small></div></div><div class="paper"><div class="profile-row"><span>🔔</span><label>Promemoria TV</label><strong>${future.length}</strong></div><div class="profile-row"><span>🎞️</span><label>Film monitorati</label><strong>${favM.length}</strong></div><div class="profile-row"><span>📚</span><label>Libri preferiti</label><strong>${favB.length}</strong></div><div class="profile-row"><span>🔐</span><label>Dati e privacy</label><strong>Solo locali</strong></div></div>${sectionTitle('I tuoi film preferiti','films')}${favM.length?`<div class="movie-list">${favM.map(filmCard).join('')}</div>`:empty('Nessun film salvato','Tocca il cuore accanto a un film per ritrovarlo qui.')}${sectionTitle('I tuoi libri preferiti','books')}${favB.length?`<div class="books-list">${favB.map(bookCard).join('')}</div>`:empty('Nessun libro salvato','Tocca il cuore vicino a un libro.')}${sectionTitle('Film già visti')}${state.seen.length?`<div class="paper">${MOVIES.filter(m=>state.seen.includes(m.id)).map(m=>`<div class="profile-row"><span>✓</span><label>${esc(m.title)}</label><button data-action="seen" data-id="${esc(m.id)}">Rimuovi</button></div>`).join('')}</div>`:empty('La lista è ancora vuota','Apri una scheda film e premi “Già visto”.')}${sectionTitle('Promemoria TV')}${future.length?`<div class="paper">${future.map(r=>`<div class="profile-row"><span>🔔</span><label>${esc(r.title)}<br><small>${dateLocal(new Date(r.when),{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})} · ${esc(r.channel)}</small></label><button data-action="delReminder" data-id="${esc(r.id)}">✕</button></div>`).join('')}</div>`:empty('Nessun promemoria','Nella Guida TV puoi selezionare un film in programma e attivare un promemoria.')}
<p class="setting-note">I dati sono salvati sul dispositivo. Nessun account, profilazione o abbonamento richiesto. Su Android le notifiche dipendono dai permessi del sistema.</p><button class="small-button" data-action="resetData">Cancella tutti i miei dati locali</button></section>`;}
function render(){const renderers={home:renderHome,films:renderFilms,tv:renderTv,books:renderBooks,advent:renderAdvent,profile:renderProfile};el('screen').innerHTML=(renderers[state.tab]||renderHome)();document.querySelectorAll('#nav [data-tab]').forEach(b=>{const active=b.dataset.tab===state.tab;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'page':'false')});requestMedia();}
function platformUrl(provider,title){const q=encodeURIComponent(title);if(provider==='Netflix')return `https://www.netflix.com/search?q=${q}`;if(provider==='Disney+')return 'https://www.disneyplus.com/it-it/search';if(provider==='Prime Video')return 'https://www.primevideo.com/';if(provider==='Apple TV+')return 'https://tv.apple.com/it';return 'https://www.justwatch.com/it';}
function detailMovie(id){const m=movieById(id);if(!m)return;const fav=state.favMovies.includes(id);const seen=state.seen.includes(id);const tvMatches=state.tv.filter(p=>norm(p.title).includes(norm(m.title))||norm(m.title).includes(norm(p.title))).filter(p=>new Date(p.start)>new Date());const content=`<div class="detail-hero" data-media-kind="movie" data-media-id="${esc(m.id)}" style="${mediaPhoto(m,'movie')}"><h2 id="modalTitle">${esc(m.title)}</h2></div><div class="detail-body"><div class="gold-label" style="color:#8b623c">${esc(m.year)} · ${esc(m.genre)}</div><div class="detail-buttons"><button class="main-action" data-action="favMovie" data-id="${esc(m.id)}">${fav?'♥ Nei preferiti':'♡ Aggiungi ai preferiti'}</button><button data-action="seen" data-id="${esc(m.id)}">${seen?'✓ Già visto':'✓ Segna come visto'}</button></div><h3>✧ La trama</h3><p>${esc(m.desc)}</p><h3>✧ Dove vederlo</h3>${m.platforms.length?m.platforms.map(p=>`<div class="provider-card"><span>🎞️ ${esc(p)}</span><a href="${safeUrl(platformUrl(p,m.title))}" target="_blank" rel="noopener noreferrer">Apri ${esc(p)} ↗</a></div>`).join(''):'<p>Non è indicata una piattaforma precisa. Verifica le disponibilità aggiornate in Italia.</p>'}<div class="provider-card"><span>🔎 JustWatch Italia</span><a href="https://www.justwatch.com/it" target="_blank" rel="noopener noreferrer">Controlla la disponibilità ↗</a></div><p class="disclaimer-detail">I provider sono suggerimenti editoriali: disponibilità, costi e noleggio possono cambiare. La verifica va effettuata sulla piattaforma.</p><h3>✧ In televisione</h3>${tvMatches.length?tvMatches.slice(0,4).map(x=>`<p>📺 ${esc(x.channel)} · ${dateLocal(new Date(x.start),{weekday:'short',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</p>`).join(''):'<p>Nessun passaggio verificato nella guida caricata.</p>'}<h3>✧ Trailer ufficiale</h3><div class="provider-card"><span>▶️ Trailer su YouTube</span><a href="${safeUrl('https://www.youtube.com/results?search_query='+encodeURIComponent(m.title+' trailer ufficiale italiano'))}" target="_blank" rel="noopener noreferrer">Cerca trailer ↗</a></div><p class="modal-foot">Locandina originale recuperata dal catalogo Apple quando verificabile; altrimenti indicazione di immagine non disponibile.</p></div>`;openModal(content);}
function openModal(html){el('modalInner').innerHTML=html;el('modal').classList.remove('hidden');el('modal').setAttribute('aria-hidden','false');document.body.style.overflow='hidden';el('closeModal').focus();requestMedia();}
function closeModal(){el('modal').classList.add('hidden');el('modal').setAttribute('aria-hidden','true');document.body.style.overflow='';}
function toggle(arr,id){const i=arr.indexOf(id);if(i>=0)arr.splice(i,1);else arr.push(id);save();render();}
function reminder(i,offset){const show=state.tv.filter(p=>dateKey(new Date(p.start))===dateKey(localDay(offset)))[i];if(!show)return;const when=new Date(show.start).getTime();if(when<=Date.now()){toast('Questo programma è già iniziato.');return;}const id=`${show.channelId}:${show.start}`;if(state.reminders.some(r=>r.id===id)){toast('Promemoria già presente.');return;}const x={id,title:show.title,when,channel:show.channel};state.reminders.push(x);save();let available=false;try {if(window.NataleNative?.scheduleReminder){NataleNative.scheduleReminder(id,show.title+' su '+show.channel,when-10*60000);available=true;}}catch{}if(!available){const start=new Date(when);const from=start.toISOString().replace(/[-:]|\.\d{3}/g,'');const end=new Date(when+7200000).toISOString().replace(/[-:]|\.\d{3}/g,'');const url=`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(show.title+' - '+show.channel)}&dates=${from}/${end}`;openModal(`<div class="detail-body"><h2 id="modalTitle" class="page-title" style="color:#7c2632">Promemoria salvato</h2><p>Il film è nei tuoi promemoria locali. Per ricevere una notifica anche fuori dall'app, aggiungilo al calendario.</p><div class="detail-buttons"><a class="main-action" href="${safeUrl(url)}" target="_blank" rel="noopener noreferrer">Aggiungi a Google Calendar ↗</a></div></div>`);}else toast('Promemoria impostato: 10 minuti prima.');render();}
const actions = {
 adventOpen:(b)=>openAdventDay(Number(b.dataset.value)),
 adventPreview:()=>openAdventDay(1,true),
 adventBonus:()=>openAdventDay(25),
 favMovie:(b)=>{toggle(state.favMovies,b.dataset.id);if(!el('modal').classList.contains('hidden'))detailMovie(b.dataset.id)},
 favBook:(b)=>{toggle(state.favBooks,b.dataset.id);toast('Preferiti aggiornati')},
 seen:(b)=>{toggle(state.seen,b.dataset.id);if(!el('modal').classList.contains('hidden'))detailMovie(b.dataset.id)},
 filmFilter:(b)=>{state.filmFilter=b.dataset.value;render()},
 bookFilter:(b)=>{state.bookFilter=b.dataset.value;render()},
 date:(b)=>{state.dateOffset=Number(b.dataset.value);render()},
 toggleFree:()=>{state.showFree=!state.showFree;render()},
 clearQuery:()=>{state.query='';render();el('queryInput')?.focus()},
 refreshTv:()=>refreshTv(true),
 detail:(b)=>detailMovie(b.dataset.id),
 remind:(b)=>reminder(Number(b.dataset.value),Number(b.dataset.day)),
 delReminder:(b)=>{const i=state.reminders.findIndex(r=>r.id===b.dataset.id);if(i>=0){let id=state.reminders[i].id;state.reminders.splice(i,1);save();try{window.NataleNative?.cancelReminder?.(id);}catch{}}render()},
 resetData:()=>{if(!confirm('Vuoi cancellare preferiti, film visti e promemoria salvati su questo dispositivo?'))return;state.favMovies=[];state.favBooks=[];state.seen=[];state.reminders=[];save();render();toast('Dati locali cancellati.');},
};
document.addEventListener('click', e=>{const t=e.target.closest('[data-action],[data-tab]');if(!t)return;if(t.dataset.action && actions[t.dataset.action]){e.preventDefault();e.stopPropagation();actions[t.dataset.action](t);return;}if(t.dataset.tab){e.preventDefault();nav(t.dataset.tab);}});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-action="detail"],.feature-card')){e.preventDefault();e.target.click();}if(e.key==='Escape')closeModal()});
document.addEventListener('input',e=>{if(e.target.id!=='queryInput')return;const pos=e.target.selectionStart;state.query=e.target.value;render();const n=el('queryInput');if(n){n.focus();n.setSelectionRange(pos,pos);}});
document.addEventListener('click', e=>{const a=e.target.closest('a[href]');if(!a||!/^https:\/\//i.test(a.href))return;try{if(window.NataleNative?.openUrl){e.preventDefault();NataleNative.openUrl(a.href);}}catch{}},true);
el('closeModal').addEventListener('click',closeModal);el('modal').addEventListener('click',e=>{if(e.target===el('modal'))closeModal()});el('alertsBtn').addEventListener('click',()=>nav('profile'));
// L'app funziona offline per i cataloghi. La guida TV si aggiorna solo se online.
render();refreshTv();
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();
