# Io Amo la Magia del Natale — V9

- Nuovo tema grafico con **azzurro brillante**, fondo neve/avorio, oro, rosso Natale, lucine, fiocchi, illustrazione originale con slitta di Babbo Natale e albero decorato.
- Home rinnovata: quattro sezioni principali e «La magia di oggi».
- Calendario dell’Avvento con 24 caselle, una coppia film/libro per giorno, sblocco progressivo dal 1° al 24 dicembre, sorpresa del 25 dicembre e anteprima dimostrativa del 1° giorno fuori stagione.
- Locandine film da Apple/iTunes e copertine libri da Google Books; cache e controllo su titolo, autore e anno; nessuna decorazione del brand mascherata da locandina ufficiale.
- Guida TV: selezione 14 giorni, con evidenza chiara dei limiti del palinsesto effettivamente pubblicato; collegamenti alla guida TV esterna. Orario locale Italia.
- Sezioni Film, Guida TV, Libri, Avvento e Preferiti, con font grandi, spaziature e touch target adeguati.
- Spazio promozionale identificato come **segnaposto** in anteprima, nessun AdMob attivo. Per attivare advertising reale sono necessari identificativi del publisher, SDK pubblicitario e CMP certificata/consenso.
- Codice affiliato Amazon.it memorizzato per la **versione web**, disabilitato nel wrapper APK in attesa dell'approvazione specifica dell'app da Amazon.

## Fonti e limiti

Calendario: le 24 coppie sono **nuove proposte editoriali per l'app** basate sul catalogo disponibile; non sono una trascrizione completa del calendario già presente nel sito/blog, il cui elenco giornaliero non è stato reperito.

La disponibilità streaming non è verificata in tempo reale; i pulsanti delle piattaforme conducono alle relative schede di ricerca. Le copertine sono richieste ai cataloghi a runtime (rete necessaria) e possono essere assenti quando l'abbinamento non è affidabile.

I palinsesti TV futuri dipendono dalla copertura effettiva della fonte: la presenza del selettore 14 giorni non garantisce 14 giorni di programmi.

Per creare un APK debug firmato, usare Android Studio o il workflow GitHub incluso. Non dichiarare un APK valido fino al completamento della build.
