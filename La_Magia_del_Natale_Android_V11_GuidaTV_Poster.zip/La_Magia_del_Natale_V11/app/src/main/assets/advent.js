/* Calendario editoriale V9. Gli abbinamenti film/libro sono proposte per l'app,
   NON una copia certificata dei contenuti del calendario presente sul sito. */
window.ADVENT_DAYS = [
 [1,'La prima scintilla','klaus','b1','Ogni Natale inizia da un piccolo gesto gentile.'],
 [2,'Una lettera dal Polo Nord','chronicles','b2','Tra renne, lettere e promesse comincia il viaggio.'],
 [3,'Un cuore da scaldare','grinch','b3','Anche il cuore più burbero può cambiare.'],
 [4,'Il treno delle meraviglie','polar','b4','Sali a bordo: la magia è per chi continua a crederci.'],
 [5,'La notte dei desideri','noelle','b7','La strada verso Natale è fatta di incontri e coraggio.'],
 [6,'Un dono inatteso','homealone','b10','Il regalo più bello non è sempre quello più grande.'],
 [7,'La porta incantata','nightmare','b5','Ogni fiaba apre una porta verso un mondo inatteso.'],
 [8,'La luce delle famiglie','muppets','b6','Ritrova la magia delle storie raccontate insieme.'],
 [9,'Un piccolo eroe','boy','b8','Il coraggio si nasconde anche nei più piccoli.'],
 [10,'Sotto le stelle','wonderful','b12','Una stella può ricordarci quanto siamo importanti.'],
 [11,'Le campanelle della gioia','santa','b11','A volte basta credere un poco di più.'],
 [12,'La casa dei ricordi','homealone2','b14','Il Natale sa trasformare ogni casa in un ricordo.'],
 [13,'La notte delle storie','carol','b13','Lasciati sorprendere da una storia senza tempo.'],
 [14,'Un abbraccio d’inverno','holiday','b15','Una nuova amicizia può scaldare anche il giorno più freddo.'],
 [15,'Il mistero sotto l’albero','miracle','b9','La meraviglia si nasconde spesso nei dettagli.'],
 [16,'Un sorriso da regalare','charlie','b16','Un sorriso gentile illumina un intero villaggio.'],
 [17,'Un mondo da inventare','jingle','b2','Con fantasia e affetto, tutto diventa possibile.'],
 [18,'Neve e biscotti','falling','b4','Concediti una pausa dolce e un momento speciale.'],
 [19,'Racconti al caminetto','diary','b1','Le storie riuniscono chi è lontano.'],
 [20,'Un Natale da cantare','spirited','b12','La musica accompagna i ricordi più belli.'],
 [21,'Un messaggio d’amore','love','b10','Le parole più semplici sono spesso quelle che contano.'],
 [22,'I sogni diventano luce','tiffany','b7','Le coincidenze più magiche nascono con il cuore aperto.'],
 [23,'Preparativi incantati','candy','b5','Il profumo di cannella annuncia la Vigilia.'],
 [24,'La notte più magica','chronicles2','b6','Accendi una luce e condividi la magia di Natale.']
];
window.ADVENT_BONUS = [25,'La sorpresa di Natale','scrooge','b11','Un piccolo dono speciale per continuare a sognare.'];
