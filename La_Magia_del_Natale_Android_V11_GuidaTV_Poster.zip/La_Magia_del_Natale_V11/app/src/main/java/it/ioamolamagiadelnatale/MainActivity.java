package it.ioamolamagiadelnatale;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.time.OffsetDateTime;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatterBuilder;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MainActivity extends Activity {
    private static final String EPG = "https://tvit.leicaflorianrobert.dev/epg/list.json";
    private static final String CHANNELS = "https://tvit.leicaflorianrobert.dev/iptv/list.json";
    // XMLTV multi-canale: fonte supplementare con circa 260 canali italiani; orizzonte da verificare ogni aggiornamento.
    private static final String ITALY_XMLTV = "https://xmltv.live/epg/it.xml.gz";
    private WebView web;
    private final ExecutorService artworkExecutor = Executors.newFixedThreadPool(3);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff1c639b);
        getWindow().setNavigationBarColor(0xff1c639b);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setTextZoom(115); // Lettura agevolata su display piccoli.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);  // only bundled android_asset URLs
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(), "NataleNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openIfExternal(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openIfExternal(Uri.parse(url));
            }
        });
        ReminderReceiver.ensureChannel(this);
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean openIfExternal(Uri uri) {
        if ("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/")) return false;
        if ("https".equalsIgnoreCase(uri.getScheme())) openExternal(uri.toString());
        return true;
    }
    private void openExternal(String link) {
        if (link == null || !link.startsWith("https://")) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))); }
        catch (ActivityNotFoundException ex) { Toast.makeText(this, "Browser non disponibile", Toast.LENGTH_SHORT).show(); }
    }

    private static String readUrl(String urlStr) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(8500); conn.setReadTimeout(10500);
        conn.setRequestProperty("User-Agent", "NataleMagicoApp/11.0 (+GuidaTV)");
        conn.setRequestProperty("Accept", "application/json");
        try {
            int status = conn.getResponseCode();
            if (status != 200) throw new Exception("HTTP " + status);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer,0,n);
                    if(out.size() > 25_000_000) throw new Exception("Guida TV troppo grande");
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { conn.disconnect(); }
    }

    private static boolean looksChristmas(String title, String description, String category) {
        String t = title.toLowerCase(Locale.ITALIAN);
        String d = description.toLowerCase(Locale.ITALIAN);
        String c = category.toLowerCase(Locale.ITALIAN);
        String[] titles = {"natale","christmas","xmas","babbo","santa claus","santa clause","grinch","scrooge","polar express","schiaccianoci","miracolo sulla 34","miracolo nella 34","mamma, ho perso","mamma ho perso","mamma, ho riperso","festa in casa muppet","holiday","love actually","una poltrona per due","elf -","elf:","jingle jangle","klaus","noelle","frosty","re magi","la vita è meravigliosa","il diario segreto di noel","elf","le cronache di natale","a christmas carol","buon natale da candy cane lane","il principe di natale","love actually"};
        for (String term : titles) if(t.contains(term))return true;
        if(t.equals("elf") || t.equals("noelle") || t.equals("the holiday") || t.equals("home alone"))return true;
        if (c.contains("film") || c.contains("cinema")) {
            return d.contains("natale") || d.contains("christmas") || d.contains("babbo natale") || d.contains("vigilia") || d.contains("polo nord");
        }
        return false;
    }

    private void sendToWeb(String payload) {
        if(web != null)runOnUiThread(() -> web.evaluateJavascript(
            "window.nativeGuideReady(" + JSONObject.quote(payload) + ");", null));
    }
    // Guida multipla: una sorgente non può far fallire le altre.
    private void fetchGuide() {
        new Thread(() -> {
            JSONArray shows=new JSONArray(), channels=new JSONArray(), sources=new JSONArray(), warnings=new JSONArray();
            JSONObject coverage=new JSONObject();
            boolean primaryOk=false, secondaryOk=false;
            try {
                JSONArray epg=new JSONArray(readUrl(EPG));
                primaryOk=true;
                for(int i=0;i<epg.length();i++){
                    JSONObject ch=epg.optJSONObject(i);if(ch==null)continue;
                    JSONArray list=ch.optJSONArray("programs");if(list==null)continue;
                    String id=ch.optString("id", "tvit-"+i);
                    channels.put(new JSONObject().put("id",id).put("name",ch.optString("name",id))
                        .put("guide","https://www.superguidatv.it/programmazione-tv/"));
                    for(int j=0;j<list.length();j++){
                        JSONObject pr=list.optJSONObject(j);if(pr==null)continue;
                        String start=pr.optString("start","");
                        addCoverage(coverage,start);
                        String title=pr.optString("title",""),desc=pr.optString("description",""),cat=pr.optString("category","");
                        if(!looksChristmas(title,desc,cat))continue;
                        shows.put(new JSONObject().put("title",title).put("desc",desc).put("category",cat)
                            .put("start",start).put("end",pr.optString("end",""))
                            .put("channelId",id).put("source","TvIt"));
                    }
                }
                try {
                    JSONArray raw=new JSONArray(readUrl(CHANNELS));
                    for(int i=0;i<raw.length();i++){
                        JSONObject ch=raw.optJSONObject(i);if(ch==null)continue;
                        channels.put(new JSONObject().put("id",ch.optString("tvg_slug",""))
                            .put("name",ch.optString("name",""))
                            .put("number",ch.opt("dtt_num"))
                            .put("guide",ch.optString("raw_guide_link","https://www.superguidatv.it/programmazione-tv/")));
                    }
                }catch(Exception ignored){}
                sources.put("TvIt / SuperGuidaTV");
            }catch(Exception error){ warnings.put("TvIt non disponibile"); }

            // Fonte indipendente: XMLTV di 7 giorni per canale; richiesta di rete parallela.
            // Prima della distribuzione commerciale verificare le autorizzazioni del titolare.
            String[][] stations={
                {"rai-1.it","Rai 1"},{"rai-2.it","Rai 2"},{"rai-3.it","Rai 3"},
                {"rai-4.it","Rai 4"},{"rai-movie.it","Rai Movie"},{"rai-premium.it","Rai Premium"},
                {"rai-gulp.it","Rai Gulp"},{"rai-yoyo.it","Rai Yoyo"},
                {"rete-4.it","Rete 4"},{"canale-5.it","Canale 5"},{"italia-1.it","Italia 1"},
                {"la-5.it","La5"},{"italia-2.it","Italia 2"},{"iris.it","Iris"},
                {"mediaset-extra.it","Mediaset Extra"},{"top-crime.it","Top Crime"}
            };
            ExecutorService pool=Executors.newFixedThreadPool(6);
            List<Future<ChannelResult>> futures=new ArrayList<>();
            for(String[] ch:stations){
                final String slug=ch[0],name=ch[1];
                futures.add(pool.submit(()->loadSevenDayChannel(slug,name)));
            }
            pool.shutdown();
            for(Future<ChannelResult> f:futures){
                try {
                    ChannelResult ch=f.get(14,TimeUnit.SECONDS);
                    if(ch==null)continue;
                    secondaryOk=true;
                    JSONObject channel=new JSONObject().put("id",ch.id).put("name",ch.name)
                        .put("guide","https://cristianlivella.com/xmltv/");
                    int number=terrestrialNumber(ch.name);if(number>0)channel.put("number",number);
                    channels.put(channel);
                    for(int k=0;k<ch.programmes.length();k++)shows.put(ch.programmes.optJSONObject(k));
                    for(String day:ch.coveredDays)coverage.put(day,coverage.optInt(day,0)+1);
                }catch(Exception ignored){} // fallimento di un canale non blocca la guida
            }
            pool.shutdownNow();
            if(secondaryOk)sources.put("Cristian Livella XMLTV (fino a 7 giorni)");
            // Terza fonte: XMLTV nazionale aggregato con canali come TV8 e canali cinema.
            // Parser SAX streaming per evitare di caricare decine di MB nel DOM su Android.
            try {
                SourceResult extended=loadItalianXmltv();
                if(extended.channels.length()>0) {
                    for(int x=0;x<extended.channels.length();x++)channels.put(extended.channels.getJSONObject(x));
                    for(int x=0;x<extended.programmes.length();x++)shows.put(extended.programmes.getJSONObject(x));
                    for(String day:extended.coveredDays)coverage.put(day,coverage.optInt(day,0)+1);
                    sources.put("XMLTV.live Italia (copertura reale per data)");
                    secondaryOk=true;
                } else warnings.put("XMLTV nazionale senza programmi utilizzabili");
            }catch(Exception exception){warnings.put("XMLTV nazionale non raggiungibile");}
            else warnings.put("Fonte XMLTV a 7 giorni non raggiungibile");
            if(!primaryOk&&!secondaryOk){
                try{sendToWeb(new JSONObject().put("error","Nessuna fonte TV raggiungibile: controlla Internet e riprova.").toString());}
                catch(Exception ignored){}
                return;
            }
            try{sendToWeb(new JSONObject().put("shows",shows).put("channels",channels)
                .put("coverage",coverage).put("sources",sources).put("warnings",warnings).toString());}
            catch(Exception ignored){}
        },"GuidaTV-Multifonte").start();
    }

    private static String dateKey(String start){
        try{return Instant.parse(start).atZone(ZoneId.of("Europe/Rome")).toLocalDate().toString();}
        catch(Exception ex){
            try{return OffsetDateTime.parse(start).atZoneSameInstant(ZoneId.of("Europe/Rome")).toLocalDate().toString();}
            catch(Exception ignored){return "";}
        }
    }
    private static void addCoverage(JSONObject coverage,String start) {
        String key=dateKey(start);if(key.isEmpty())return;
        try{coverage.put(key,coverage.optInt(key,0)+1);}catch(Exception ignored){}
    }
    private static String xmlText(Element root,String tag){
        NodeList nodes=root.getElementsByTagName(tag);
        return nodes.getLength()>0?nodes.item(0).getTextContent().trim():"";
    }
    private static String parseXmlTime(String raw){
        try{
            String[] parts=raw.trim().split("\\s+");
            if(parts.length<2)return "";
            String timestamp=parts[0];
            if(timestamp.length()==12)timestamp+="00";
            if(timestamp.length()!=14)return "";
            return OffsetDateTime.parse(timestamp+" "+parts[1],
                DateTimeFormatter.ofPattern("yyyyMMddHHmmss Z",Locale.US)).toInstant().toString();
        }catch(Exception ignored){return "";}
    }
    private static int terrestrialNumber(String channel){
        String n=channel.toLowerCase(Locale.ITALIAN).trim().replace(" ","");
        switch(n){
            case "rai1":return 1;case "rai2":return 2;case "rai3":return 3;case "rete4":return 4;
            case "canale5":return 5;case "italia1":return 6;case "rai4":return 21;
            case "raimovie":return 24;case "raipremium":return 25;case "raiulp":case "raigulp":return 42;
            case "raiyoyo":return 43;case "iris":return 22;case "tv8":return 8;
            case "nove":return 9;case "cielo":return 26;case "la7cinema":return 29;
            case "twentyseven":case "27twentyseven":return 27;case "la5":return 30;
            case "italia2":return 49;case "mediasetextra":return 55;case "topcrime":return 39;
            default:return 0;
        }
    }
    private static class ChannelResult {
        String id,name; Set<String> coveredDays=new HashSet<>();JSONArray programmes=new JSONArray();
        ChannelResult(String id,String name){this.id=id;this.name=name;}
    }
    private static ChannelResult loadSevenDayChannel(String slug,String name){
        HttpURLConnection conn=null;
        try{
            String url="https://cristianlivella.com/xmltvfiles/"+slug+".xml";
            conn=(HttpURLConnection)new URL(url).openConnection();
            conn.setConnectTimeout(6500);conn.setReadTimeout(9000);
            conn.setRequestProperty("Accept","application/xml,text/xml");
            conn.setRequestProperty("User-Agent","NataleMagicoApp/11.0 (+XMLTV)");
            if(conn.getResponseCode()!=200)return null;
            // Bound di sicurezza: 5 MB per guida singolo canale.
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            try(InputStream in=conn.getInputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>5_000_000)return null;}
            }
            DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
            factory.setXIncludeAware(false);factory.setExpandEntityReferences(false);
            org.w3c.dom.Document doc=factory.newDocumentBuilder().parse(new ByteArrayInputStream(out.toByteArray()));
            ChannelResult result=new ChannelResult("livella-"+slug,name);
            NodeList programmes=doc.getElementsByTagName("programme");
            long max=System.currentTimeMillis()+14L*86400000L,min=System.currentTimeMillis()-86400000L;
            for(int i=0;i<programmes.getLength();i++){
                Element item=(Element)programmes.item(i);
                String start=parseXmlTime(item.getAttribute("start")),end=parseXmlTime(item.getAttribute("stop"));
                if(start.isEmpty()||end.isEmpty())continue;
                long when;
                try{when=Instant.parse(start).toEpochMilli();}catch(Exception ignored){continue;}
                if(when<min||when>max)continue;
                String key=dateKey(start);if(!key.isEmpty())result.coveredDays.add(key);
                String title=xmlText(item,"title"),desc=xmlText(item,"desc"),category=xmlText(item,"category");
                if(!looksChristmas(title,desc,category))continue;
                result.programmes.put(new JSONObject().put("title",title).put("desc",desc)
                    .put("category",category).put("start",start).put("end",end)
                    .put("channelId",result.id).put("source","Cristian Livella XMLTV"));
            }
            return result;
        }catch(Exception ignored){return null;}
        finally{if(conn!=null)conn.disconnect();}
    }

    private static class SourceResult {
        JSONArray programmes=new JSONArray(),channels=new JSONArray();
        Set<String> coveredDays=new HashSet<>();
    }
    // Limite sulla dimensione decompattata per proteggere i telefoni con poca RAM.
    private static class LimitedStream extends FilterInputStream {
        long used=0, limit;
        LimitedStream(InputStream in,long limit){super(in);this.limit=limit;}
        @Override public int read() throws IOException {int c=super.read();if(c!=-1&&++used>limit)throw new IOException("Guida TV troppo grande");return c;}
        @Override public int read(byte[] b,int o,int l)throws IOException {int n=super.read(b,o,l);if(n>0&&(used+=n)>limit)throw new IOException("Guida TV troppo grande");return n;}
    }
    private static String bestStationName(String label,String fallback){
        String v=label==null?"":label.trim();return v.isEmpty()?fallback:v;
    }
    private static SourceResult loadItalianXmltv() throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(ITALY_XMLTV).openConnection();
        conn.setConnectTimeout(8000);conn.setReadTimeout(12000);
        conn.setRequestProperty("User-Agent","NataleMagicoApp/11.0 (Italia EPG)");
        conn.setRequestProperty("Accept","application/gzip,application/xml,*/*");
        try{
            if(conn.getResponseCode()!=200)throw new IOException("Guida Italia HTTP "+conn.getResponseCode());
            SourceResult result=new SourceResult();
            Map<String,String> names=new HashMap<>();
            SAXParserFactory factory=SAXParserFactory.newInstance();
            factory.setNamespaceAware(false);factory.setValidating(false);
            factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
            factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);
            try(InputStream raw=new LimitedStream(conn.getInputStream(),9_000_000L);
                InputStream xml=new LimitedStream(new GZIPInputStream(raw),65_000_000L)){
                factory.newSAXParser().parse(xml,new DefaultHandler(){
                    StringBuilder buf=new StringBuilder();
                    String id="",station="",channel="",title="",desc="",category="",start="",stop="";
                    String current="";boolean readingChannel=false,readingProgram=false;
                    int total=0;
                    @Override public void startElement(String uri,String local,String q,Attributes a){
                        current=q;buf.setLength(0);
                        if("channel".equals(q)){readingChannel=true;id=a.getValue("id");station="";}
                        else if("programme".equals(q)){
                            readingProgram=true;channel=a.getValue("channel");start=a.getValue("start");stop=a.getValue("stop");
                            title="";desc="";category="";
                        }
                    }
                    @Override public void characters(char[] chars,int off,int length){
                        if(buf.length()<10000)buf.append(chars,off,Math.min(length,10000-buf.length()));
                    }
                    @Override public void endElement(String uri,String local,String q){
                        String v=buf.toString().trim();
                        if(readingChannel && "display-name".equals(q)&&station.isEmpty())station=v;
                        if(readingProgram){
                            if("title".equals(q)&&title.isEmpty())title=v;
                            if("desc".equals(q)&&desc.isEmpty())desc=v;
                            if("category".equals(q)&&category.isEmpty())category=v;
                        }
                        if("channel".equals(q)&&readingChannel){
                            String name=bestStationName(station,id);
                            if(id!=null){names.put(id,name);try{
                                JSONObject ch=new JSONObject().put("id","xmltv-it-"+id).put("name",name)
                                .put("guide","https://xmltv.live/epg/?lang=it");
                                int number=terrestrialNumber(name);if(number>0)ch.put("number",number);
                                result.channels.put(ch);
                            }catch(Exception ignored){}}
                            readingChannel=false;
                        }
                        if("programme".equals(q)&&readingProgram){
                            readingProgram=false;total++;
                            if(total<120000){
                                String startTime=parseXmlTime(start==null?"":start),endTime=parseXmlTime(stop==null?"":stop);
                                if(!startTime.isEmpty()&&!endTime.isEmpty()){
                                    long when=0;
                                    try{when=Instant.parse(startTime).toEpochMilli();}catch(Exception ignored){}
                                    long now=System.currentTimeMillis();
                                    if(when>=now-86400000L&&when<=now+14L*86400000L){
                                        String day=dateKey(startTime);if(!day.isEmpty())result.coveredDays.add(day);
                                        if(looksChristmas(title,desc,category))try{
                                            result.programmes.put(new JSONObject().put("title",title).put("desc",desc)
                                            .put("category",category).put("start",startTime).put("end",endTime)
                                            .put("channelId","xmltv-it-"+channel).put("source","XMLTV.live Italia"));
                                        }catch(Exception ignored){}
                                    }
                                }
                            }
                        }
                        buf.setLength(0);current="";
                    }
                });
            }
            // Se i canali mancano ma esistono programmi non usare numeri presunti.
            return result;
        }finally{conn.disconnect();}
    }

    // Copertine non inventate: solo risultati verificati per titolo/autore o film/anno.
    private static String canon(String input) {
        String s = Normalizer.normalize(input == null ? "" : input, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ITALIAN);
        return s.replaceAll("[^a-z0-9]+", " ").trim().replaceAll(" +", " ");
    }
    private static boolean titleMatch(String a,String b) {
        String x=canon(a), y=canon(b);
        if(x.isEmpty() || y.isEmpty())return false;
        return x.equals(y) || (x.length()>5 && y.startsWith(x+" ")) || (y.length()>5 && x.startsWith(y+" "));
    }
    private static boolean imageAvailable(String url) {
        if(url==null||!url.startsWith("https://"))return false;
        HttpURLConnection conn=null;
        try {
            conn=(HttpURLConnection)new URL(url).openConnection();
            conn.setConnectTimeout(6500);conn.setReadTimeout(6500);
            // Non usare Range: diversi CDN di copertine lo rifiutano.
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Accept","image/*");
            conn.setRequestProperty("User-Agent","NataleMagicoApp/11.0");
            int code=conn.getResponseCode();
            String type=conn.getContentType();
            if(!(code==200||code==206)||type==null||!type.toLowerCase(Locale.US).startsWith("image/"))return false;
            try(InputStream in=conn.getInputStream()){return in.read()!=-1;}
        }catch(Exception ignored){return false;}
        finally{if(conn!=null)conn.disconnect();}
    }
    private static String findMovieArt(String title,int year) throws Exception {
        String local=canon(title);
        Map<String,String> aliases=new HashMap<>();
        aliases.put("klaus i segreti del natale","Klaus");
        aliases.put("qualcuno salvi il natale","The Christmas Chronicles");
        aliases.put("qualcuno salvi il natale 2","The Christmas Chronicles 2");
        aliases.put("mamma ho perso l aereo","Home Alone");
        aliases.put("mamma ho riperso l aereo mi sono smarrito a new york","Home Alone 2 Lost in New York");
        aliases.put("il grinch","The Grinch");
        aliases.put("polar express","The Polar Express");
        aliases.put("nightmare before christmas","The Nightmare Before Christmas");
        aliases.put("santa clause","The Santa Clause");
        aliases.put("festa in casa muppet","The Muppet Christmas Carol");
        aliases.put("jingle jangle un avventura natalizia","Jingle Jangle A Christmas Journey");
        aliases.put("un bambino chiamato natale","A Boy Called Christmas");
        aliases.put("il diario segreto di noel","The Noel Diary");
        aliases.put("scrooge canto di natale","Scrooge A Christmas Carol");
        aliases.put("l amore non va in vacanza","The Holiday");
        aliases.put("la vita e meravigliosa","It's a Wonderful Life");
        aliases.put("miracolo nella 34 strada","Miracle on 34th Street");
        aliases.put("spirited magia di natale","Spirited");
        aliases.put("buon natale da candy cane lane","Candy Cane Lane");
        aliases.put("uno rosso red one","Red One");
        List<String> variants=new ArrayList<>();variants.add(title);
        String original=aliases.getOrDefault(local,"");
        if(!original.isEmpty()&&!canon(original).equals(local))variants.add(original);

        // Primo tentativo: catalogo cinema che include anche originali delle piattaforme.
        // Scartare locandine con titolo/anno discordanti, mai attribuire immagini casuali.
        for(String query:variants){
            try{
                String endpoint="https://v3-cinemeta.strem.io/catalog/movie/top/search="
                    +URLEncoder.encode(query,"UTF-8")+".json";
                JSONArray list=new JSONObject(readUrl(endpoint)).optJSONArray("metas");
                if(list==null)continue;
                int maxScore=-999;String candidateUrl="";
                for(int i=0;i<list.length();i++){
                    JSONObject film=list.optJSONObject(i);if(film==null)continue;
                    String name=film.optString("name","");
                    if(!titleMatch(name,query) && !titleMatch(name,title))continue;
                    int y=0;String info=film.optString("releaseInfo",film.optString("year",""));
                    java.util.regex.Matcher mat=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(info);
                    if(mat.find())try{y=Integer.parseInt(mat.group());}catch(Exception ignored){}
                    int delta=(year>0&&y>0)?Math.abs(year-y):0;
                    if(delta>2)continue;
                    String poster=film.optString("poster","");
                    int score=100-15*delta+(titleMatch(name,title)?10:0);
                    if(poster.startsWith("https://")&&score>maxScore){maxScore=score;candidateUrl=poster;}
                }
                if(imageAvailable(candidateUrl))return candidateUrl;
            }catch(Exception ignored){}
        }
        // Secondo tentativo: Apple (non tutti i film delle piattaforme sono nel negozio).
        String best="";int bestScore=-100;
        for(String q:variants)for(String country:new String[]{"it","us"}){
            try{
                String url="https://itunes.apple.com/search?term="+URLEncoder.encode(q,"UTF-8")
                    +"&media=movie&entity=movie&country="+country+"&limit=30";
                JSONArray results=new JSONObject(readUrl(url)).optJSONArray("results");
                if(results==null)continue;
                for(int i=0;i<results.length();i++){
                    JSONObject film=results.optJSONObject(i);if(film==null)continue;
                    String candidate=film.optString("trackName","");
                    if(!titleMatch(title,candidate)&&!(!original.isEmpty()&&titleMatch(original,candidate)))continue;
                    int itemYear=0;
                    try{itemYear=Integer.parseInt(film.optString("releaseDate","").substring(0,4));}catch(Exception ignored){}
                    int delta=year>0&&itemYear>0?Math.abs(year-itemYear):0;
                    if(delta>3)continue;
                    String urlArt=film.optString("artworkUrl100","");
                    if(!urlArt.startsWith("https://"))continue;
                    int score=100-delta+(canon(candidate).equals(canon(title))||canon(candidate).equals(canon(original))?30:0);
                    if(score>bestScore){bestScore=score;best=urlArt.replace("100x100bb","600x600bb");}
                }
            }catch(Exception ignored){}
        }
        return imageAvailable(best)?best:"";
    }
    private static String findBookArt(String title,String author) throws Exception {
        String surname=canon(author);
        if(surname.contains(" "))surname=surname.substring(surname.lastIndexOf(' ')+1);
        for(String q:new String[]{"intitle:"+title+" inauthor:"+author,"intitle:"+title}){
            try{
                String url="https://www.googleapis.com/books/v1/volumes?q="+URLEncoder.encode(q,"UTF-8")+"&maxResults=30";
                JSONArray results=new JSONObject(readUrl(url)).optJSONArray("items");
                if(results==null)continue;
                for(int i=0;i<results.length();i++){
                    JSONObject book=results.optJSONObject(i);if(book==null)continue;
                    JSONObject info=book.optJSONObject("volumeInfo");if(info==null)continue;
                    if(!titleMatch(title,info.optString("title","")))continue;
                    JSONArray authors=info.optJSONArray("authors");boolean authorOk=false;
                    if(authors!=null)for(int j=0;j<authors.length();j++)
                        if(canon(authors.optString(j)).contains(surname)){authorOk=true;break;}
                    if(!authorOk)continue;
                    JSONObject cover=info.optJSONObject("imageLinks");if(cover==null)continue;
                    String address=cover.optString("large",cover.optString("medium",cover.optString("thumbnail","")));
                    if(address.startsWith("http://"))address="https://"+address.substring(7);
                    if(address.startsWith("https://") && imageAvailable(address))return address;
                }
            }catch(Exception ignored){}
        }
        // Copertine Open Library, solo dopo corrispondenza di titolo e autore.
        try{
            String search="https://openlibrary.org/search.json?title="+URLEncoder.encode(title,"UTF-8")
                +"&author="+URLEncoder.encode(author,"UTF-8")+"&fields=title,author_name,cover_i&limit=15";
            JSONArray docs=new JSONObject(readUrl(search)).optJSONArray("docs");
            if(docs!=null)for(int i=0;i<docs.length();i++){
                JSONObject book=docs.optJSONObject(i);if(book==null||!titleMatch(title,book.optString("title","")))continue;
                JSONArray authors=book.optJSONArray("author_name");boolean good=false;
                if(authors!=null)for(int j=0;j<authors.length();j++)
                    if(canon(authors.optString(j)).contains(surname)){good=true;break;}
                if(good && book.optInt("cover_i",0)>0){
                    String cover="https://covers.openlibrary.org/b/id/"+book.optInt("cover_i")+"-L.jpg?default=false";
                    if(imageAvailable(cover))return cover;
                }
            }
        }catch(Exception ignored){}
        return "";
    }
    private void fetchArtwork(String kind,String id,String title,String author,int year){
        if(!("movie".equals(kind)||"book".equals(kind)) || id.length()>50 || title.length()>140)return;
        artworkExecutor.execute(()->{
            String url="";
            try{url="movie".equals(kind)?findMovieArt(title,year):findBookArt(title,author);}catch(Exception ignored){}
            try {
                JSONObject response=new JSONObject();
                response.put("kind",kind).put("id",id).put("url",url)
                    .put("source","movie".equals(kind)?"Cinemeta / Apple iTunes":"Google Books / Open Library");
                String text=response.toString();
                if(web!=null)runOnUiThread(()->web.evaluateJavascript("window.nativeArtworkReady("+JSONObject.quote(text)+");",null));
            }catch(Exception ignored){}
        });
    }

    public class Bridge {
        @JavascriptInterface public void loadGuide(){fetchGuide();}
        @JavascriptInterface public void requestArtwork(String kind,String id,String title,String author,int year){fetchArtwork(kind,id,title,author,year);}
        @JavascriptInterface public boolean isAffiliateApproved(){ return false; /* Set true only AFTER Amazon approves this mobile app. */ }
        @JavascriptInterface public void openUrl(String url){runOnUiThread(() -> openExternal(url));}
        @JavascriptInterface public void scheduleReminder(String id, String title, long when) {
            if (when < System.currentTimeMillis()) return;
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
                }
            });
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            it.putExtra("title",title);it.putExtra("id",id);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            // No exact-alarm permission required. Android may delay this notification slightly.
            if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }
        @JavascriptInterface public void cancelReminder(String id){
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(am!=null && pi!=null){am.cancel(pi);pi.cancel();}
        }
    }
    @Override @SuppressWarnings("deprecation") public void onBackPressed() {
        web.evaluateJavascript("window.nataleBack ? window.nataleBack() : false", result -> {
            if(!"true".equals(result))runOnUiThread(this::finish);
        });
    }
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
