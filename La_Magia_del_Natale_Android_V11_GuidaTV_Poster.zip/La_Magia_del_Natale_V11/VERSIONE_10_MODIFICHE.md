# Io Amo la Magia del Natale — Versione 10.0 (correzioni TV e copertine)

## Modifiche implementate

- **Guida TV Android multifonte:** la fonte TvIt rimane, ma il suo fallimento non blocca più la guida. Fonte alternativa aggiunta: guide XMLTV a 7 giorni dichiarati per 16 canali Rai/Mediaset pubblicate da Cristian Livella (https://cristianlivella.com/xmltv/). Le richieste per canale sono in parallelo con timeout e controlli dei file XML (nessuna DTD esterna).
- **Giorni futuri:** rimosso il limite interno a nove giorni; la UI permette 14 date ma ora marca *Guida online* solo quelle che hanno effettivi dati di programmazione e *Non pubblicato* gli altri giorni. Nessun orario inventato. I programmi della stessa rete e orario sono deduplicati.
- **Copertine film:** ricerca nel catalogo Apple iTunes IT e US con controllo di titolo/anno. Immagini provate realmente prima di essere restituite su Android; non si scaricano immagini a caso.
- **Copertine libri:** ricerca Google Books con controllo titolo/autore; seconda fonte Open Library Search + Covers API (https://openlibrary.org/dev/docs/api/covers), con controllo dell'immagine esistente.
- **Cache immagini:** un risultato negativo dura due ore invece di 14 giorni; un risultato positivo dura 21 giorni e il caricamento dell'immagine viene controllato anche dal browser/WebView. Cache del catalogo V7 non viene riusata.
- **Interfaccia:** resta lo stile natalizio azzurro della V9, con gli stessi menu, preferiti, Avvento, modalità di apertura dei film e libri.
- **Aggiornamento:** `versionCode` 10 e `versionName` 10.0.0. Mantiene l'`applicationId` e le chiavi localStorage, per preservare i preferiti dopo aggiornamento con stessa firma.

## Limiti dichiarati

- Questa ZIP contiene il **sorgente**, non un APK compilato. Nel nostro ambiente non è disponibile Android SDK/Gradle; i test Android e la verifica live dei feed vanno fatti dopo la compilazione.
- Le fonti TV possono cessare di funzionare o offrire una copertura inferiore a sette giorni. La dicitura «7 giorni» è quella pubblicata dal fornitore, non una garanzia. L'anteprima HTML non può usare il download XMLTV nativo di Android: la copertura migliore si ottiene sull'APK.
- **Diritti commerciali:** la fonte XMLTV pubblica URL per l'uso con decoder/software, ma non abbiamo accertato una licenza di ridistribuzione commerciale per l'app con pubblicità. Prima di pubblicare o monetizzare l'app richiedere un permesso scritto al fornitore o scegliere un provider EPG con contratto/API, ad esempio https://www.guidatv.uno/api/ (servizio con autenticazione). Lo stesso principio vale per le locandine di film e copertine editoriali.
- Le fonti Apple/Google/Open Library non garantiscono copertine per tutti i titoli e le edizioni, né la disponibilità streaming. Non mostrare illustrazioni decorative come locandine ufficiali.
- Pubblicità AdMob non attivata: necessitano account, ID unità, SDK, consenso UMP/CMP. Amazon: affiliazione disattivata nella build Android finché il programma non approva l'app.

## Compilazione

Nell'ambiente Codex con Android SDK 35, Java 17 e Gradle 8.10.2:

`gradle --no-daemon assembleDebug`

APK atteso `app/build/outputs/apk/debug/app-debug.apk`. Verificare su Samsung che TV di domani mostri orari quando pubblicati, che i giorni non disponibili siano marcati, e che i singoli film/libri recuperino copertine da fonti HTTPS.

Questo pacchetto è aggiornato ai problemi segnalati il 19 novembre 2026.
