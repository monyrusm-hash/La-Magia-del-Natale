# Io Amo la Magia del Natale 10.0

Progetto Android (non APK) con grafica natalizia azzurra, ricerca film, libri/eBook, Calendario dell’Avvento, guida TV italiana, promemoria e predisposizione pubblicitaria.

**Leggi `VERSIONE_10_MODIFICHE.md` per correzioni, limiti, condizioni d’uso e istruzioni APK.**

Usa Java 17, Android SDK 35 e Gradle 8.10.2. Con il codice estratto dalla ZIP nella cartella radice, esegui `gradle --no-daemon assembleDebug`.
