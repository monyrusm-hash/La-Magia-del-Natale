# Versione Android 9.0 — Io Amo la Magia del Natale

**Progetto completo sorgente**, non APK già compilato. Caricare i file estratti nel repository GitHub/ambiente Codex, mantenendo `.github/workflows/build-apk.yml`, poi avviare `gradle --no-daemon assembleDebug`.

- Android 8.0+; Gradle 8.10.2, Java 17, compile SDK 35
- Sorgenti Android: `app/src/main/java/it/ioamolamagiadelnatale/`
- Interfaccia: `app/src/main/assets/index.html` + `app.js`, `catalog.js`, `advent.js`, `natale-magico-v9.css`
- Illustrazione natalizia originale: `assets/hero_natale_v9.webp`
- 24 caselline Avvento + sorpresa del 25 dicembre, consultabili solo al loro giorno locale (Europa/Roma). Prima di dicembre il pulsante anteprima del 1° giorno mostra un *esempio*.
- Film e libri: locandine/copertine reali recuperate da Apple iTunes e Google Books se la corrispondenza viene verificata (servizio online necessario). Non garantito il 100% del catalogo.
- TV: fonte primaria TvIt/SuperGuidaTV e supplementare open-epg. La vista può selezionare 14 giorni ma la copertura del servizio può essere inferiore. Non inventare programmi.
- Promemoria: Android AlarmManager per trasmissioni programmate; richiede permessi notifiche.
- Dati utente salvati solo sul telefono (localStorage). Niente login né tracking pubblicitario.
- Pubblicità: solo **spazio dimostrativo**. Per monetizzazione vera servono account AdMob, ID dell'app/unità, SDK, UMP e CMP conforme in UE. Non è stata implementata trasmissione di dati personali a reti pubblicitarie.
- Affiliate Amazon `monyka87-21` nella versione web; sul wrapper Android rimane disattivata finché l'app non è approvata dal programma.
- I 24 abbinamenti film/libro sono una proposta editoriale nuova, non l'esportazione certificata dell'Avvento sul sito.

## Creazione APK con Codex

1. Estrai questo ZIP, aggiungi i singoli file nella radice del repository GitHub, oppure usa direttamente l'archivio nell'ambiente Codex e fai `unzip ...`.
2. Avvia `gradle --no-daemon assembleDebug` nel progetto con Android SDK 35 disponibile.
3. Verifica file generato `app/build/outputs/apk/debug/app-debug.apk`, installazione su dispositivo Android e caricamento di guide/copertine con Internet.
4. Se vuoi usare GitHub Actions, carica il workflow e scarica l'artefatto `Natale-Magico-debug-APK` dopo una build riuscita.

## Stato test

Controlli statici JavaScript e test browser dell'anteprima completati. La compilazione Android **non** è stata eseguita in questo ambiente, che non dispone di SDK/Gradle e non ha accesso alla rete per installarli.
