# Monetizzazione — cosa è pronto e cosa manca

## Già presente nella V9

- Posizione editoriale riconoscibile come **spazio promozionale**, senza mostrare annunci finti né tracciare utenti.
- Link ai libri cartacei e Kindle che nella versione web possono usare il tag Amazon.it `monyka87-21`, con informativa affiliate.
- La versione Android non attiva l'affiliazione prima dell'approvazione di Amazon Associates per l'app.
- Dati di preferiti e letture salvati localmente: nessun login o invio dei dati a un backend della nostra app.

## Da attivare prima della pubblicazione con entrate reali

1. Registrare l'app in **Google AdMob** per ottenere un App ID Android e gli ID delle unità pubblicitarie (banner/native): **non** usare ID fittizi in produzione.
2. Aggiungere il Google Mobile Ads SDK nel progetto Gradle e integrare un banner/ad native Android controllato dal layout (non un generico blocco HTML che dice pubblicità).
3. Integrare una CMP certificata conforme al TCF, ad esempio il modulo UMP SDK, con informativa e opzioni di consenso per SEE/UE, UK e Svizzera. Non caricare annunci personalizzati prima dei consensi necessari. Pubblicare l'informativa privacy e consentire la gestione successiva delle preferenze.
4. Verificare l'app-ads.txt e le policy Google Play prima della pubblicazione. Verificare i contenuti promozionali per bambini/famiglie se la distribuzione rientra in tali categorie.
5. Richiedere, ove necessario, approvazione specifica per l'app nel programma Amazon Affiliati; mostrare il disclosure e fornire l'informativa commerciale.
6. Concludere test dell'installazione, dei palinsesti TV, del recupero copertine e degli annunci TEST su più dispositivi prima di pubblicare.

Riferimenti: https://developers.google.com/admob/android/privacy/gdpr e https://support.google.com/admob/answer/13554116

**Stato V9**: pubblicità solo predisposta, **nessuna campagna pubblicitaria attiva e nessun guadagno generato**.
