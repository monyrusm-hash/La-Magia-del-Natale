package it.ioamolamagiadelnatale;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.time.OffsetDateTime;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatterBuilder;
import java.util.HashSet;
import java.util.Set;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    // La fonte TvIt è stata disattivata: risultava ferma a gennaio 2026.

    // XMLTV multi-canale: fonte supplementare con circa 260 canali italiani; orizzonte da verificare ogni aggiornamento.
    private WebView web;
    private static final String LOCAL_ART_HOST="natale.assets.local";
    private final AtomicBoolean guideBusy = new AtomicBoolean(false);
    private final ExecutorService artworkExecutor = Executors.newFixedThreadPool(5);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff1c639b);
        getWindow().setNavigationBarColor(0xff1c639b);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setBlockNetworkImage(false);
        settings.setTextZoom(125); // Lettura agevolata su display piccoli.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);  // only bundled android_asset URLs
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(), "NataleNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && LOCAL_ART_HOST.equals(uri.getHost())
                        && uri.getPath()!=null && uri.getPath().startsWith("/media/")) {
                    String fileName=uri.getLastPathSegment();
                    if(fileName!=null && fileName.matches("[a-zA-Z0-9_-]{1,100}\\.(jpg|png|webp)")) {
                        File file=new File(new File(getCacheDir(),"media-v15"),fileName);
                        if(file.isFile()) try {
                            String mime=fileName.endsWith(".png")?"image/png":fileName.endsWith(".webp")?"image/webp":"image/jpeg";
                            return new WebResourceResponse(mime,null,new FileInputStream(file));
                        } catch(IOException ignored){}
                    }
                    return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view,request);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openIfExternal(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openIfExternal(Uri.parse(url));
            }
        });
        ReminderReceiver.ensureChannel(this);
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean openIfExternal(Uri uri) {
        if ("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/")) return false;
        if ("https".equalsIgnoreCase(uri.getScheme())) openExternal(uri.toString());
        return true;
    }
    private void openExternal(String link) {
        if (link == null || !link.startsWith("https://")) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))); }
        catch (ActivityNotFoundException ex) { Toast.makeText(this, "Browser non disponibile", Toast.LENGTH_SHORT).show(); }
    }

    private static String readUrl(String urlStr) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(5500); conn.setReadTimeout(6500);
        conn.setRequestProperty("User-Agent", "NataleMagicoApp/15.0");
        conn.setRequestProperty("Accept", "application/json");
        try {
            int status = conn.getResponseCode();
            if (status != 200) throw new Exception("HTTP " + status);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer,0,n);
                    if(out.size() > 25_000_000) throw new Exception("Guida TV troppo grande");
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { conn.disconnect(); }
    }

    private static boolean looksChristmas(String title, String description, String category) {
        String t = title.toLowerCase(Locale.ITALIAN);
        String d = description.toLowerCase(Locale.ITALIAN);
        String c = category.toLowerCase(Locale.ITALIAN);
        String[] titles = {"natale","christmas","xmas","babbo","santa claus","santa clause","grinch","scrooge","polar express","schiaccianoci","miracolo sulla 34","miracolo nella 34","mamma, ho perso","mamma ho perso","mamma, ho riperso","festa in casa muppet","holiday","love actually","una poltrona per due","elf -","elf:","jingle jangle","klaus","noelle","frosty","re magi","la vita è meravigliosa","il diario segreto di noel","elf","le cronache di natale","a christmas carol","buon natale da candy cane lane","il principe di natale","love actually"};
        for (String term : titles) if(t.contains(term))return true;
        if(t.equals("elf") || t.equals("noelle") || t.equals("the holiday") || t.equals("home alone"))return true;
        if (c.contains("film") || c.contains("cinema")) {
            return d.contains("natale") || d.contains("christmas") || d.contains("babbo natale") || d.contains("vigilia") || d.contains("polo nord");
        }
        return false;
    }

    private void sendToWeb(String payload) {
        if(web != null)runOnUiThread(() -> web.evaluateJavascript(
            "window.nativeGuideReady(" + JSONObject.quote(payload) + ");", null));
    }
    private void guideProgress(String message) {
        if(web!=null)runOnUiThread(()->web.evaluateJavascript("window.nativeGuideProgress("+JSONObject.quote(message)+");",null));
    }
    private void sendGuideSnapshot(JSONArray shows, JSONArray channels, JSONObject coverage,
            JSONArray sources,JSONArray warnings) {
        try{sendToWeb(new JSONObject().put("shows",shows).put("channels",channels)
                .put("coverage",coverage).put("sources",sources).put("warnings",warnings).toString());}
        catch(Exception ignored){}
    }
    private static boolean isFilmCategory(String category) {
        String c=category==null?"":category.toLowerCase(Locale.ITALIAN);
        return c.contains("film")||c.contains("movie")||c.contains("cinema")||c.contains("fiction");
    }
    // V14: nessuna programmazione fittizia e nessun feed con licenza non verificata.
    // Un provider autorizzato può esporre i palinsesti aggregati tramite HTTPS in formato JSON.
    private void fetchGuide() {
        if(!guideBusy.compareAndSet(false,true))return;
        new Thread(()->{
            JSONArray shows=new JSONArray(), channels=new JSONArray(), sources=new JSONArray(), warnings=new JSONArray();
            JSONObject coverage=new JSONObject();
            try {
                String configText;
                try(InputStream configStream=getAssets().open("tv-provider.json");ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buf=new byte[2048];int n;
                    while((n=configStream.read(buf))!=-1)out.write(buf,0,n);
                    configText=out.toString("UTF-8");
                }
                JSONObject config=new JSONObject(configText);
                String endpoint=config.optString("feedUrl","").trim();
                if(!config.optBoolean("rightsConfirmed",false)||!endpoint.startsWith("https://")) {
                    if(BuildConfig.DEBUG){
                        fetchDebugEpg();
                    }else{
                        sendToWeb(new JSONObject().put("error","La guida TV commerciale richiede un fornitore autorizzato. Attiva il feed HTTPS con i relativi diritti d'uso.")
                            .put("status","provider_not_configured").toString());
                    }
                    return;
                }
                guideProgress("Scarico i programmi dal fornitore autorizzato…");
                JSONObject data=new JSONObject(readUrl(endpoint));
                JSONArray rawShows=data.optJSONArray("shows"),rawChannels=data.optJSONArray("channels");
                if(rawShows==null||rawChannels==null)throw new IOException("Il fornitore non usa il formato guida previsto");
                for(int i=0;i<rawChannels.length();i++) {
                    JSONObject c=rawChannels.optJSONObject(i);if(c!=null&&c.has("id")&&c.has("name"))channels.put(c);
                }
                long now=System.currentTimeMillis(),max=now+14L*86400000L;
                for(int i=0;i<rawShows.length()&&i<120000;i++) {
                    JSONObject p=rawShows.optJSONObject(i);if(p==null)continue;
                    String title=p.optString("title","").trim(),start=p.optString("start","");
                    if(title.isEmpty()||start.isEmpty()||p.optString("channelId","").isEmpty())continue;
                    String date=dateKey(start); if(date.isEmpty())continue;
                    long when;
                    try{when=Instant.parse(start).toEpochMilli();}catch(Exception e){
                        try{when=OffsetDateTime.parse(start).toInstant().toEpochMilli();}catch(Exception ignored){continue;}
                    }
                    if(when<now-86400000L||when>max)continue;
                    coverage.put(date,coverage.optInt(date,0)+1);
                    String category=p.optString("category",""),description=p.optString("desc","");
                    boolean xmas=looksChristmas(title,description,category);
                    if(xmas||isFilmCategory(category)){
                        JSONObject copy=new JSONObject(p.toString());
                        copy.put("christmas",xmas);
                        copy.put("source",data.optString("provider","Guida autorizzata"));
                        shows.put(copy);
                    }
                }
                if(data.has("generatedAt")){
                    try{
                        long age=now-Instant.parse(data.optString("generatedAt","")).toEpochMilli();
                        if(age>48L*3600000L)warnings.put("ATTENZIONE: i palinsesti non sono aggiornati da oltre 48 ore");
                    }catch(Exception ignored){}
                }
                sources.put(data.optString("provider", "Fornitore EPG autorizzato"));
                if(coverage.length()==0)warnings.put("Il fornitore non ha pubblicato programmi nel periodo richiesto");
                sendGuideSnapshot(shows,channels,coverage,sources,warnings);
            } catch(Exception e) {
                try { sendToWeb(new JSONObject().put("error","Impossibile leggere il palinsesto: "+e.getClass().getSimpleName())
                        .put("status","provider_error").toString());} catch(Exception ignored){}
            } finally {guideBusy.set(false);}
        }, "Natale-Guida-Verificata-V14").start();
    }

    // V15: sorgente pubblicamente consultabile SOLO NELL'APK DEBUG, per il test
    // personale di date e interfaccia. Non usarla in distribuzione commerciale
    // senza autorizzazione del titolare dei palinsesti.
    private static final String[][] TEST_EPG_CHANNELS = {
        {"rai-1.it","Rai 1","1"}, {"rai-2.it","Rai 2","2"},
        {"rai-3.it","Rai 3","3"}, {"rai-4.it","Rai 4","21"},
        {"rai-movie.it","Rai Movie","24"}, {"rai-premium.it","Rai Premium","25"},
        {"canale-5.it","Canale 5","5"}, {"italia-1.it","Italia 1","6"},
        {"rete-4.it","Rete 4","4"}, {"iris.it","Iris","22"},
        {"la-5.it","La5","30"}, {"italia-2.it","Italia 2","49"}
    };
    private static String xmltvTimeToIso(String x){
        if(x==null||x.isEmpty())return "";
        try {
            String clean=x.trim().replaceAll("\\s+"," ");
            if(clean.matches("\\d{12} [+-]\\d{4}"))clean=clean.substring(0,12)+"00"+clean.substring(12);
            if(clean.matches("\\d{14}")){
                return java.time.LocalDateTime.parse(clean,DateTimeFormatter.ofPattern("yyyyMMddHHmmss",Locale.ROOT))
                    .atZone(ZoneId.of("Europe/Rome")).toInstant().toString();
            }
            return OffsetDateTime.parse(clean,DateTimeFormatter.ofPattern("yyyyMMddHHmmss Z",Locale.ROOT))
                .toInstant().toString();
        }catch(Exception ignored){return "";}
    }
    private static JSONObject readXmltvProgrammes(String channelId, long minTime, long maxTime) throws Exception {
        String url="https://cristianlivella.com/xmltvfiles/"+channelId+".xml";
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(5500);conn.setReadTimeout(7000);
        conn.setRequestProperty("Accept","application/xml,text/xml,*/*");
        conn.setRequestProperty("User-Agent","NataleMagicoApp/15 (test personale XMLTV)");
        try {
            if(conn.getResponseCode()!=200)throw new IOException("HTTP "+conn.getResponseCode());
            XmlPullParserFactory factory=XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(false);
            XmlPullParser parser=factory.newPullParser();
            JSONArray out=new JSONArray();
            JSONObject coverage=new JSONObject();
            try(InputStream in=conn.getInputStream()){
                parser.setInput(new InputStreamReader(in,StandardCharsets.UTF_8));
                int event=parser.getEventType(),seen=0;
                String title="",desc="",category="",start="",stop="";
                boolean inProgramme=false;
                while(event!=XmlPullParser.END_DOCUMENT && seen<2500){
                    if(event==XmlPullParser.START_TAG){
                        String tag=parser.getName();
                        if("programme".equals(tag)){
                            inProgramme=true;title="";desc="";category="";
                            start=xmltvTimeToIso(parser.getAttributeValue(null,"start"));
                            stop=xmltvTimeToIso(parser.getAttributeValue(null,"stop"));
                            seen++;
                        }else if(inProgramme && "title".equals(tag))title=parser.nextText().trim();
                        else if(inProgramme && "desc".equals(tag))desc=parser.nextText().trim();
                        else if(inProgramme && "category".equals(tag)){
                            String val=parser.nextText().trim();
                            category+=(category.isEmpty()?"":", ")+val;
                        }
                    }else if(event==XmlPullParser.END_TAG && "programme".equals(parser.getName()) && inProgramme){
                        inProgramme=false;
                        long epoch=0;
                        try{epoch=Instant.parse(start).toEpochMilli();}catch(Exception ignored){}
                        if(epoch>=minTime && epoch<=maxTime && !title.isEmpty()){
                            String day=dateKey(start);
                            if(!day.isEmpty())coverage.put(day,coverage.optInt(day,0)+1);
                        }
                        if(epoch>=minTime && epoch<=maxTime && !title.isEmpty()
                            && (looksChristmas(title,desc,category)||isFilmCategory(category)
                                || desc.toLowerCase(Locale.ITALIAN).contains("film di "))){
                            out.put(new JSONObject().put("channelId",channelId).put("title",title)
                                .put("desc",desc).put("category",category).put("start",start).put("end",stop)
                                .put("christmas",looksChristmas(title,desc,category))
                                .put("source","XMLTV test"));
                        }
                    }
                    event=parser.next();
                }
            }
            return new JSONObject().put("shows",out).put("coverage",coverage);
        }finally{conn.disconnect();}
    }
    private void fetchDebugEpg(){
        guideProgress("Modalità prova: consulto 12 canali TV per i prossimi giorni…");
        JSONArray shows=new JSONArray(),channels=new JSONArray(),sources=new JSONArray(),warnings=new JSONArray();
        JSONObject coverage=new JSONObject();
        long now=System.currentTimeMillis(),max=now+7L*86400000L;
        ExecutorService pool=Executors.newFixedThreadPool(6);
        CountDownLatch latch=new CountDownLatch(TEST_EPG_CHANNELS.length);
        List<JSONObject> results=java.util.Collections.synchronizedList(new ArrayList<>());
        List<String> errors=java.util.Collections.synchronizedList(new ArrayList<>());
        for(String[] ch:TEST_EPG_CHANNELS){
            pool.execute(()->{
                try{
                    JSONObject data=readXmltvProgrammes(ch[0],now-12L*3600000L,max);
                    results.add(new JSONObject().put("channel",new JSONArray(ch))
                        .put("programmes",data.getJSONArray("shows"))
                        .put("coverage",data.getJSONObject("coverage")));
                }catch(Exception ex){errors.add(ch[1]+": "+ex.getClass().getSimpleName());}
                finally{latch.countDown();}
            });
        }
        try{latch.await(29,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        pool.shutdownNow();
        try{
            for(JSONObject entry:new ArrayList<>(results)){
                JSONArray arr=entry.getJSONArray("programmes");
                JSONObject dates=entry.getJSONObject("coverage");
                java.util.Iterator<String> keys=dates.keys();
                while(keys.hasNext()){
                    String d=keys.next();coverage.put(d,coverage.optInt(d,0)+dates.optInt(d,0));
                }
                JSONArray ch=entry.getJSONArray("channel");
                channels.put(new JSONObject().put("id",ch.getString(0))
                    .put("name",ch.getString(1)).put("number",ch.getString(2)));
                for(int j=0;j<arr.length();j++){
                    JSONObject program=arr.getJSONObject(j);
                    shows.put(program);

                }
            }
            sources.put("Cristian Livella XMLTV (prova personale)");
            warnings.put("Dati TV di prova: la fonte non è autorizzata per la distribuzione commerciale. Copertura effettiva variabile.");
            if(!errors.isEmpty())warnings.put(errors.size()+" canali non hanno risposto: "+String.join(", ",errors.subList(0,Math.min(3,errors.size()))));
            if(shows.length()==0)warnings.put("Nessun film trovato per le date pubblicate: consulta le guide esterne.");
            sendGuideSnapshot(shows,channels,coverage,sources,warnings);
        }catch(Exception ex){
            try{sendToWeb(new JSONObject().put("error","Errore nel lettore XMLTV: "+ex.getClass().getSimpleName()).toString());}catch(Exception ignored){}
        }
    }

    private static String dateKey(String start){
        try{return Instant.parse(start).atZone(ZoneId.of("Europe/Rome")).toLocalDate().toString();}
        catch(Exception ex){
            try{return OffsetDateTime.parse(start).atZoneSameInstant(ZoneId.of("Europe/Rome")).toLocalDate().toString();}
            catch(Exception ignored){return "";}
        }
    }
    // Copertine non inventate: solo risultati verificati per titolo/autore o film/anno.
    private static String canon(String input) {
        String s = Normalizer.normalize(input == null ? "" : input, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ITALIAN);
        return s.replaceAll("[^a-z0-9]+", " ").trim().replaceAll(" +", " ");
    }
    private static boolean titleMatch(String a,String b) {
        String x=canon(a), y=canon(b);
        if(x.isEmpty() || y.isEmpty())return false;
        return x.equals(y) || (x.length()>5 && y.startsWith(x+" ")) || (y.length()>5 && x.startsWith(y+" "));
    }
    private static boolean imageAvailable(String url) {
        if(url==null||!url.startsWith("https://"))return false;
        HttpURLConnection conn=null;
        try {
            conn=(HttpURLConnection)new URL(url).openConnection();
            conn.setConnectTimeout(6500);conn.setReadTimeout(6500);
            // Non usare Range: diversi CDN di copertine lo rifiutano.
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Accept","image/*");
            conn.setRequestProperty("User-Agent","NataleMagicoApp/13.0");
            int code=conn.getResponseCode();
            String type=conn.getContentType();
            if(!(code==200||code==206)||type==null||!type.toLowerCase(Locale.US).startsWith("image/"))return false;
            try(InputStream in=conn.getInputStream()){return in.read()!=-1;}
        }catch(Exception ignored){return false;}
        finally{if(conn!=null)conn.disconnect();}
    }
    // Ricerca mirata per evitare decine di richieste e timeout per ciascuna immagine.
    private static String findMovieArt(String title,int year,String imdbId) throws Exception {
        if(imdbId!=null && imdbId.matches("tt\\d{7,9}")) {
            try {
                JSONObject meta=new JSONObject(readUrl("https://v3-cinemeta.strem.io/meta/movie/"+imdbId+".json")).optJSONObject("meta");
                String poster=meta==null?"":meta.optString("poster","");
                if(poster.startsWith("https://"))return poster;
            }catch(Exception ignored){}
        }
        String query=title;
        Map<String,String> aliases=new HashMap<>();
        aliases.put("qualcuno salvi il natale","The Christmas Chronicles");
        aliases.put("qualcuno salvi il natale 2","The Christmas Chronicles 2");
        aliases.put("mamma ho perso l aereo","Home Alone");
        aliases.put("mamma ho riperso l aereo mi sono smarrito a new york","Home Alone 2 Lost in New York");
        aliases.put("l amore non va in vacanza","The Holiday");
        aliases.put("la vita e meravigliosa","It's a Wonderful Life");
        aliases.put("festa in casa muppet","The Muppet Christmas Carol");
        aliases.put("polar express","The Polar Express");
        aliases.put("miracolo nella 34 strada","Miracle on 34th Street");
        aliases.put("buon natale da candy cane lane","Candy Cane Lane");
        aliases.put("klaus i segreti del natale","Klaus");
        query=aliases.getOrDefault(canon(title),title);
        try {
            String endpoint="https://v3-cinemeta.strem.io/catalog/movie/top/search="
                +URLEncoder.encode(query,"UTF-8")+".json";
            JSONArray list=new JSONObject(readUrl(endpoint)).optJSONArray("metas");
            if(list!=null){
                String best="";int score=-10000;
                for(int i=0;i<Math.min(list.length(),15);i++){
                    JSONObject f=list.optJSONObject(i);if(f==null)continue;
                    if(!titleMatch(query,f.optString("name","")))continue;
                    String poster=f.optString("poster","");if(!poster.startsWith("https://"))continue;
                    int foundYear=0;
                    java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(f.optString("releaseInfo",f.optString("year","")));
                    if(m.find())try{foundYear=Integer.parseInt(m.group());}catch(Exception ignored){}
                    if(year>0&&foundYear>0&&Math.abs(year-foundYear)>2)continue;
                    int pts=100-(year>0&&foundYear>0?Math.abs(year-foundYear)*20:10);
                    if(pts>score){best=poster;score=pts;}
                }
                if(!best.isEmpty())return best;
            }
        }catch(Exception ignored){}
        // Ultimo tentativo: la ricerca Apple limitata a un mercato, senza preflight delle immagini.
        try{
            String api="https://itunes.apple.com/search?term="+URLEncoder.encode(query,"UTF-8")
                +"&media=movie&entity=movie&country=it&limit=20";
            JSONArray results=new JSONObject(readUrl(api)).optJSONArray("results");
            if(results!=null)for(int i=0;i<results.length();i++){
                JSONObject film=results.optJSONObject(i);if(film==null)continue;
                if(!titleMatch(query,film.optString("trackName","")))continue;
                int y=0;try{y=Integer.parseInt(film.optString("releaseDate","").substring(0,4));}catch(Exception ignored){}
                if(year>0&&y>0&&Math.abs(year-y)>2)continue;
                String image=film.optString("artworkUrl100","");
                if(image.startsWith("https://"))return image.replace("100x100bb","600x600bb");
            }
        }catch(Exception ignored){}
        return "";
    }
    private static String findBookArt(String title,String author) throws Exception {
        String last=canon(author);if(last.contains(" "))last=last.substring(last.lastIndexOf(' ')+1);
        // Open Library: nessuna chiave e copertina identificata dal record con autore corrispondente.
        try{
            String url="https://openlibrary.org/search.json?title="+URLEncoder.encode(title,"UTF-8")
              +"&author="+URLEncoder.encode(author,"UTF-8")+"&fields=title,author_name,cover_i&limit=12";
            JSONArray docs=new JSONObject(readUrl(url)).optJSONArray("docs");
            if(docs!=null)for(int i=0;i<docs.length();i++){
                JSONObject book=docs.optJSONObject(i);if(book==null||!titleMatch(title,book.optString("title","")))continue;
                JSONArray authors=book.optJSONArray("author_name");boolean ok=false;
                if(authors!=null)for(int j=0;j<authors.length();j++)if(canon(authors.optString(j)).contains(last)){ok=true;break;}
                int cover=book.optInt("cover_i",0);
                if(ok&&cover>0)return "https://covers.openlibrary.org/b/id/"+cover+"-M.jpg?default=false";
            }
        }catch(Exception ignored){}
        // Alternativa: Google Books, un solo tentativo e titolo/autore verificati.
        try{
            String q="intitle:"+title+" inauthor:"+author;
            JSONArray items=new JSONObject(readUrl("https://www.googleapis.com/books/v1/volumes?q="
                +URLEncoder.encode(q,"UTF-8")+"&maxResults=15")).optJSONArray("items");
            if(items!=null)for(int i=0;i<items.length();i++){
                JSONObject obj=items.optJSONObject(i),inf=obj==null?null:obj.optJSONObject("volumeInfo");if(inf==null)continue;
                if(!titleMatch(title,inf.optString("title","")))continue;
                JSONArray authors=inf.optJSONArray("authors");boolean ok=false;
                if(authors!=null)for(int j=0;j<authors.length();j++)if(canon(authors.optString(j)).contains(last)){ok=true;break;}
                JSONObject images=inf.optJSONObject("imageLinks");if(!ok||images==null)continue;
                String url=images.optString("medium",images.optString("thumbnail",""));
                if(url.startsWith("http://"))url="https://"+url.substring(7);
                if(url.startsWith("https://"))return url;
            }
        }catch(Exception ignored){}
        return "";
    }
    // Fonte alternativa solo se il link alla prima immagine non e' scaricabile.
    private static String findMovieArtApple(String title,int year){
        try{
            String url="https://itunes.apple.com/search?term="+URLEncoder.encode(title,"UTF-8")
              +"&media=movie&entity=movie&country=it&limit=20";
            JSONArray items=new JSONObject(readUrl(url)).optJSONArray("results");
            if(items!=null)for(int i=0;i<items.length();i++){
                JSONObject m=items.optJSONObject(i);if(m==null)continue;
                if(!titleMatch(title,m.optString("trackName","")))continue;
                int y=0;try{y=Integer.parseInt(m.optString("releaseDate","").substring(0,4));}catch(Exception ignored){}
                if(year>0&&y>0&&Math.abs(year-y)>2)continue;
                String art=m.optString("artworkUrl100","");
                if(art.startsWith("https://"))return art.replace("100x100bb","600x600bb");
            }
        }catch(Exception ignored){}
        return "";
    }
    private static String findBookArtGoogle(String title,String author){
        try{
            String surname=canon(author);if(surname.contains(" "))surname=surname.substring(surname.lastIndexOf(' ')+1);
            String q="intitle:"+title+" inauthor:"+author;
            JSONArray items=new JSONObject(readUrl("https://www.googleapis.com/books/v1/volumes?q="
                +URLEncoder.encode(q,"UTF-8")+"&maxResults=20")).optJSONArray("items");
            if(items!=null)for(int i=0;i<items.length();i++){
                JSONObject o=items.optJSONObject(i),inf=o==null?null:o.optJSONObject("volumeInfo");
                if(inf==null||!titleMatch(title,inf.optString("title","")))continue;
                JSONArray authors=inf.optJSONArray("authors");boolean ok=false;
                if(authors!=null)for(int j=0;j<authors.length();j++)if(canon(authors.optString(j)).contains(surname)){ok=true;break;}
                JSONObject imgs=inf.optJSONObject("imageLinks");if(!ok||imgs==null)continue;
                String url=imgs.optString("thumbnail","").replace("http://","https://");
                if(url.startsWith("https://"))return url;
            }
        }catch(Exception ignored){}
        return "";
    }
    // Le immagini validate vengono salvate sul dispositivo: la WebView non deve scaricarle
    // direttamente da un dominio esterno (che puo' respingere richieste file://).
    private String localCachedCover(String kind,String id) {
        String stem=(kind+"-"+id).replaceAll("[^a-zA-Z0-9_-]","_");
        File dir=new File(getCacheDir(),"media-v15");
        for(String ext:new String[]{"jpg","png","webp"}) {
            File f=new File(dir,stem+"."+ext);
            if(f.isFile()&&f.length()>100)return "https://"+LOCAL_ART_HOST+"/media/"+f.getName();
        }
        return "";
    }
    private String saveCoverLocally(String kind,String id,String remoteUrl) {
        if(remoteUrl==null || !remoteUrl.startsWith("https://"))return "";
        HttpURLConnection conn=null;
        File tmp=null;
        try {
            conn=(HttpURLConnection)new URL(remoteUrl).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(5500);conn.setReadTimeout(6500);
            conn.setRequestProperty("Accept","image/avif,image/webp,image/png,image/jpeg,*/*");
            conn.setRequestProperty("User-Agent","Mozilla/5.0 NataleMagico/15.0");
            if(conn.getResponseCode()!=200)return "";
            String mime=conn.getContentType();
            if(mime==null)return "";
            mime=mime.toLowerCase(Locale.US);
            String extension=mime.startsWith("image/jpeg")?"jpg":mime.startsWith("image/png")?"png":mime.startsWith("image/webp")?"webp":"";
            if(extension.isEmpty())return "";
            File dir=new File(getCacheDir(),"media-v15");
            if(!dir.exists()&&!dir.mkdirs())return "";
            String stem=(kind+"-"+id).replaceAll("[^a-zA-Z0-9_-]","_");
            File destination=new File(dir,stem+"."+extension);
            tmp=new File(dir,stem+".tmp");
            try(InputStream in=conn.getInputStream(); FileOutputStream out=new FileOutputStream(tmp)) {
                byte[] bytes=new byte[8192];int count,total=0;
                while((count=in.read(bytes))!=-1){total+=count;if(total>3_000_000)return "";out.write(bytes,0,count);}
                if(total<120)return "";
            }
            if(!tmp.renameTo(destination))return "";
            return "https://"+LOCAL_ART_HOST+"/media/"+destination.getName();
        } catch(Exception ignored){return "";}
        finally {if(conn!=null)conn.disconnect();if(tmp!=null&&tmp.exists())tmp.delete();}
    }
    // Invia l'immagine già scaricata direttamente alla WebView: il browser locale non
    // ha bisogno di contattare domini fittizi o di aggirare restrizioni file://.
    private String cachedArtworkData(String kind,String id) {
        String stem=(kind+"-"+id).replaceAll("[^a-zA-Z0-9_-]","_");
        File dir=new File(getCacheDir(),"media-v15");
        for(String ext:new String[]{"jpg","png","webp"}){
            File f=new File(dir,stem+"."+ext);
            if(!f.isFile()||f.length()<120||f.length()>2500000)return "";
            try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] bytes=new byte[8192];int n;
                while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
                // Ridimensionamento a 420 px: evita script base64 molto grandi nella WebView.
                android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();
                options.inPreferredConfig=android.graphics.Bitmap.Config.RGB_565;
                android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeByteArray(out.toByteArray(),0,out.size(),options);
                if(bitmap==null)return "";
                int w=bitmap.getWidth(),h=bitmap.getHeight();
                if(w>420){android.graphics.Bitmap scaled=android.graphics.Bitmap.createScaledBitmap(bitmap,420,Math.max(1,h*420/w),true);bitmap.recycle();bitmap=scaled;}
                ByteArrayOutputStream compressed=new ByteArrayOutputStream();
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG,76,compressed);
                bitmap.recycle();
                return "data:image/jpeg;base64,"+Base64.encodeToString(compressed.toByteArray(),Base64.NO_WRAP);
            }catch(Exception ignored){}
        }
        return "";
    }
    private void fetchArtwork(String kind,String id,String title,String author,int year,String imdbId){
        if(!("movie".equals(kind)||"book".equals(kind)) || id.length()>50 || title.length()>140)return;
        artworkExecutor.execute(()->{
            String url=cachedArtworkData(kind,id),status="cache locale";
            if(url.isEmpty()) {
                try {
                    String remote="movie".equals(kind)?findMovieArt(title,year,imdbId):findBookArt(title,author);
                    saveCoverLocally(kind,id,remote);
                    url=cachedArtworkData(kind,id);
                    if(url.isEmpty() && "movie".equals(kind)){
                        String apple=findMovieArtApple(title,year);
                        if(!apple.isEmpty()&&!apple.equals(remote)){
                            saveCoverLocally(kind,id,apple);
                            url=cachedArtworkData(kind,id);
                        }
                    }
                    if(url.isEmpty() && "book".equals(kind)){
                        String google=findBookArtGoogle(title,author);
                        if(!google.isEmpty()&&!google.equals(remote)){
                            saveCoverLocally(kind,id,google);
                            url=cachedArtworkData(kind,id);
                        }
                    }
                    status=url.isEmpty()?"Catalogo non disponibile o nessuna immagine abbinata":"Immagine recuperata e salvata";
                }catch(Exception ex){status="Errore catalogo: "+ex.getClass().getSimpleName();}
            }
            try {
                JSONObject response=new JSONObject().put("kind",kind).put("id",id).put("url",url).put("status",status);
                String text=response.toString();
                if(web!=null)runOnUiThread(()->web.evaluateJavascript("window.nativeArtworkReady("+JSONObject.quote(text)+");",null));
            }catch(Exception ignored){}
        });
    }

    public class Bridge {
        @JavascriptInterface public void loadGuide(){fetchGuide();}
        @JavascriptInterface public void requestArtwork(String kind,String id,String title,String author,int year,String imdbId){fetchArtwork(kind,id,title,author,year,imdbId);}
        @JavascriptInterface public boolean isAffiliateApproved(){ return false; /* Set true only AFTER Amazon approves this mobile app. */ }
        @JavascriptInterface public void openUrl(String url){runOnUiThread(() -> openExternal(url));}
        @JavascriptInterface public void scheduleReminder(String id, String title, long when) {
            if (when < System.currentTimeMillis()) return;
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
                }
            });
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            it.putExtra("title",title);it.putExtra("id",id);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            // No exact-alarm permission required. Android may delay this notification slightly.
            if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }
        @JavascriptInterface public void cancelReminder(String id){
            AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent it=new Intent(MainActivity.this,ReminderReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,id.hashCode(),it,
                PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(am!=null && pi!=null){am.cancel(pi);pi.cancel();}
        }
    }
    @Override @SuppressWarnings("deprecation") public void onBackPressed() {
        web.evaluateJavascript("window.nataleBack ? window.nataleBack() : false", result -> {
            if(!"true".equals(result))runOnUiThread(this::finish);
        });
    }
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
