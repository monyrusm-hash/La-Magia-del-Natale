# Io Amo la Magia del Natale — V13: contenuti e diagnostica

## Novità verificate a livello di codice
- Home con sezioni Natale romantico, Natale da ridere, novità, cartoni, famiglia e collegamenti ai servizi legali di film gratuiti.
- Otto titoli editoriali aggiunti, provenienti dalle schermate di riferimento condivise dall'utente. Nessuna disponibilità streaming inventata.
- TV: 7 giorni selezionabili e indicazione della copertura reale. Collegamento diretto verificato alla guida esterna di oggi, domani e dopodomani per non lasciare l'utente senza un'azione possibile quando il feed non risponde. Per i giorni successivi si apre la guida generale.
- Corretto l'indice del promemoria quando si filtra per film natalizi.
- Le copertine di sei film hanno un identificativo IMDb verificato, per interrogare una scheda precisa prima della ricerca per titolo.
- Cache immagini V13 separata dalle ricerche fallite delle versioni precedenti.

## Limitazioni da non nascondere
La compilazione Android non e' stata effettuata in questo ambiente. Le sorgenti online TV, i poster Cinemeta e le copertine Google Books/Open Library NON sono stati testati in tempo reale da questo ambiente. Una guida di 7 giorni non puo' essere garantita per canali che ne pubblicano meno. Per un'app commerciale con annunci sono necessari provider dati e diritti di utilizzo appropriati (poster, palinsesti, trailer, disponibilita' streaming); TMDB, per esempio, richiede accordi per uso commerciale.

## Test richiesti a Codex
1. Eseguire assembleDebug e verificare firma.
2. Eseguire test del passaggio al giorno successivo e prova di richieste reali per TV8.
3. Aprire schede A Christmas Carol (2009), Klaus (2019), Nightmare Before Christmas (1993) e verificare con log il risultato rete, non assumere che le immagini esistano.
4. Verificare che i 7 pulsanti data conducano a una pagina utile anche se il feed e' vuoto.
5. Verificare le nuove sezioni della Home, i libri e il Calendario dell'Avvento.
